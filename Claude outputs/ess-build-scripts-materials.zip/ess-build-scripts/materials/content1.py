# -*- coding: utf-8 -*-
import math
from helpers import *
import diagrams as D
from mlib import fig, mini, row, img
import widget

pi = math.pi
def area(d): return pi * d * d / 4
M = lambda n: ' <span class="marks">%d</span>' % n
SY = syms('σ', 'ε', 'Δ', '√', 'π', '²', '⁻²', '⁻³', base=False)
SYO = syms('σ', 'ε', 'Δ', '√', 'π', '²', '⁻²', '⁻³', 'Ω', base=False)
N2 = 'Nmm<sup>&minus;2</sup>'; KN2 = 'kNmm<sup>&minus;2</sup>'; m3 = '&times; 10<sup>&minus;3</sup>'
sig, eps, Dl = '&sigma;', '&epsilon;', '&Delta;l'
def e3(x): return sf(x * 1000) + ' ' + m3
def sci(x, n=2):
    k = int(math.floor(math.log10(abs(x))))
    return sf(x / 10 ** k, n) + ' &times; 10<sup>&minus;%d</sup>' % (-k) if k < 0 else sf(x, n)
N5 = '../../../n5/mechanisms/materials/course-notes.html'

def STEPPER(title, figure, lines):
    """step-through worked example, in the same grey box and teal numbered steps as the other worked examples"""
    txt = ''.join('<div class="stepper-line" data-step="%d"><span class="stepper-n">%d</span><div>%s</div></div>' % (i, i, t) for i, t in enumerate(lines, 1))
    return ('      <div class="worked-example stepper" data-max="%d"><div class="worked-example-title">%s</div>'
            '<div class="stepper-fig">%s</div><div class="stepper-text">%s</div>'
            '<div class="stepper-ctrl"><button type="button" class="ctrl-btn" data-act="prev">&#x25C0; Back</button><span class="stepper-count"></span><button type="button" class="ctrl-btn" data-act="next">Next &#x25B6;</button><button type="button" class="ctrl-btn" data-act="all">Show all</button></div></div>\n') % (len(lines), title, figure, txt)

PEN, MAG = '&#x270F;&#xFE0F;', '&#x1F50D;'

def SIMT(title, query, note, height=600):
    """tensile test simulator demonstration panel; the page script points data-tsim at simulators/mat-tensile-test.html"""
    return ('      <div class="sim-panel">\n        <div class="sim-head"><span>&#x1F9EA; %s</span><a class="sim-open" target="_blank" rel="noopener" data-tsim="%s">&#x26F6; Open full screen &#x2197;</a></div>\n'
            '        <div class="tsim-wrap"><iframe class="tsim-frame" data-tsim="%s" title="Tensile test simulator: %s" loading="lazy"></iframe></div>\n'
            '        <div class="sim-note">%s</div>\n      </div>\n') % (title, query, query, title, note)
HOW = ('<p style="margin:0 0 6px;"><strong>Using the simulator:</strong> choose a specimen and press <strong>New test</strong>. The set-up panel slides away so you can watch the specimen and the graph; use the arrow at the left edge to bring it back. '
       '<strong>+ Compare</strong> adds another test to the same graph, the <strong>Mode</strong> button switches between a force&ndash;extension and a stress&ndash;strain graph, and hovering over the graph gives a reading. The elastic region is stretched out on the graph so that you can see it.</p>')
B = ''

# ================================================================ intro
B += KP('<strong>These notes build on National 5.</strong> At Higher you are expected to be confident with everything in the <a href="%s" style="color:var(--teal-800);">National 5 Materials notes</a>: the main properties of materials, choosing a material for a job, and calculating <strong>stress</strong> (&sigma; = F &divide; A) and <strong>strain</strong> (&epsilon; = &Delta;l &divide; l). Sections 2 and 3 recap these with Higher-style questions. If any of it feels unfamiliar, go back to the National 5 notes first.' % N5)
B += KP('<strong>Data booklet.</strong> The Higher data booklet gives you the formulae for stress, strain, Young&rsquo;s modulus, elastic strain energy and factor of safety, the area of a circle, and a <strong>properties of materials</strong> table (Young&rsquo;s modulus, yield stress, ultimate tensile stress and ultimate compressive stress). You must know what each formula means and when to use it, and be able to <strong>combine</strong> them: most Higher materials questions need two, three or four steps. Give stress in ' + N2 + ' and final answers to <strong>2 significant figures</strong> with units, keeping unrounded values in your calculator between steps.')
B += KP('<strong>Handwritten working.</strong> You can type your answers, or work on paper and use <strong>&#x1F4F7; Add photo</strong> beside any answer box to add a photo of your working. On a phone or tablet this opens the camera. Photos are saved with your answers and included in your PDF.')
B += P('Every structure is only as good as the material it is made from. A frame can be perfectly designed, but if one member stretches too far, cracks, corrodes or snaps, the load it carried passes to the members around it and the whole structure can fail. Engineers therefore need to know how a material will behave <em>before</em> it is used: how strong it is, how much it will stretch, whether it will spring back, and how much of a margin to leave for the things they cannot predict. At Higher you will learn how that information is found by <strong>testing</strong>, how it is read from <strong>graphs</strong> and <strong>data tables</strong>, and how it is used in <strong>calculations</strong> to choose a material and size a member safely.')

# ================================================================ 1
B += H1('Tensile Testing and Load&ndash;Extension Graphs')
B += P('The properties of a material are found by testing it. The most common test is the <strong>tensile test</strong>. A specimen of the material is clamped in a machine called a <strong>tensometer</strong> and pulled apart, slowly and steadily, while the load and the extension are measured until the specimen breaks. The results are plotted on a <strong>load&ndash;extension graph</strong>.')
B += img('tensometer-labelled.jpg', 'A tensometer with labelled parts: fixed crosshead, load cell, upper grip, test specimen with an extensometer clipped on, lower grip, moving crosshead pulling down, and a display showing load and extension', 'A tensometer: the specimen is gripped at both ends and the moving crosshead pulls it apart', 456)
B += P('Test pieces are made to a standard shape and size, with thicker ends for gripping and a narrower middle section of known <strong>gauge length</strong> and cross-sectional area. Using standard specimens means results from different laboratories, and different materials, can be compared fairly.')
B += img('test-pieces-before-after.jpg', 'A flat metal test piece before the test, and the same test piece after the test: its gauge length has increased, it has necked and it has fractured in the middle', 'A test piece before and after a tensile test. Notice the narrow &ldquo;neck&rdquo; where it broke.', 432)
B += H2('Reading a load&ndash;extension graph')
B += fig(D.regions(), 'Load&ndash;extension graph for a ductile metal such as mild steel', 560)
B += TABLE(['Point or region', 'What is happening'], [
    ['<strong>O to A</strong>', 'The graph is a straight line: extension is directly proportional to load. This is the <strong>linear</strong> part of the elastic region.'],
    ['<strong>A: limit of proportionality</strong>', 'The end of the straight line. The material is still elastic just beyond A, but extension is no longer proportional to load. (The limit of proportionality is not assessed in the exam.)'],
    ['<strong>O to B: elastic region</strong>', 'If the load is removed anywhere between O and B, the specimen returns to its original length.'],
    ['<strong>B: yield point</strong>', 'The <strong>limit of the elastic region</strong>. The material starts to stretch permanently: it &ldquo;yields&rdquo;. Beyond this the extension increases rapidly for little extra load.'],
    ['<strong>B to D: plastic region</strong>', 'Any extension here is permanent. The material will not return to its original length when the load is removed.'],
    ['<strong>C: ultimate tensile load</strong>', 'The highest point on the graph: the maximum load the specimen can carry. In a stress&ndash;strain graph this is the <strong>ultimate tensile stress (UTS)</strong>.'],
    ['<strong>C to D: necking</strong>', 'The cross-section narrows in one place (a &ldquo;neck&rdquo;), so the load it can carry falls while it keeps stretching.'],
    ['<strong>D: fracture (breaking point)</strong>', 'The specimen breaks.'],
])
B += KP('<strong>A and B in the exam.</strong> For most metals A and B are very close together, and many graphs show them as one point. You will not be asked about the limit of proportionality, but you must be able to identify the <strong>yield point</strong>: the end of the elastic region, where the material starts to deform permanently.')
B += P('Watch a full test below. The labels mark the elastic region, the yield point, the maximum force and the fracture point as the graph is drawn.')
B += SIMT('Demonstration 1 &mdash; a tensile test on mild steel', 'material=mild_steel&mode=fe&labels=1', HOW + '<p style="margin:0;"><strong>Try this:</strong> watch the specimen <strong>neck</strong> just before it breaks, and match each stage to the table above. Mild steel shows a small dip just after the yield point (an upper and a lower yield point); you do not need to know about this for the exam. Then test cast iron and compare.</p>')
B += H2('Removing the load: elastic or plastic?')
B += P('What happens when the load is taken off depends on where the specimen has reached on the graph.')
B += fig(D.unload(), 'Unloading from the elastic region and from the plastic region', 560)
B += UL('If the load is removed while the specimen is still in the <strong>elastic region</strong>, it goes back down the same line and returns to its <strong>original length</strong>.',
        'If the load is removed after the yield point, from a point such as P in the <strong>plastic region</strong>, it springs back a little along a line <strong>parallel to the elastic line</strong>, but it does not reach zero. The extension that is left is the <strong>permanent set</strong>: the specimen is now permanently longer.')
B += KP('<strong>Exam tip.</strong> &ldquo;Describe the effect of applying and then removing a load&rdquo; needs <strong>both</strong> halves: what happens while the load is on, and what happens when it is removed. For a load in the elastic region: &ldquo;the material stretches, then returns to its original length when the load is removed.&rdquo;')
B += P('The simulator above always pulls the specimen until it breaks. To see what happens when the load is removed part-way through, use the explorer below. Pick a material, drag the slider to load the specimen, then press <strong>Remove the load</strong>. Use <strong>Zoom in on the start</strong> to see the elastic region: for metals it is so short compared with the plastic region that it is almost vertical on the whole-test view, which is why exam graphs are often drawn with a stretched-out strain axis.')
B += widget.HTML
T1 = [
 dict(key='hmat-t2a', q='a) State the name of the region of the graph between 0 and 30 kN.' + M(1), a=F('The elastic region.')),
 dict(key='hmat-t2b', q='b) State the ultimate tensile load of the specimen.' + M(1), a=F('45 kN') + NOTE('The highest point on the graph, at an extension of 3.0 mm.')),
 dict(key='hmat-t2c', q='c) Describe the effect on the specimen of applying a load of 20 kN and then removing it.' + M(1),
      a='<p>The specimen stretches (by about 0.67 mm), and when the load is removed it returns to its <strong>original length</strong>, because 20 kN is in the elastic region.</p>'),
 dict(key='hmat-t2d', q='d) Describe the effect on the specimen of applying a load of 40 kN and then removing it.' + M(2),
      a='<p>40 kN is beyond the yield point, in the plastic region, so the specimen stretches permanently. When the load is removed it springs back a little but is left <strong>permanently longer</strong> than it was originally (it does not return to its original length).</p>'),
 dict(key='hmat-t2e', q='e) Describe what is happening to the specimen between extensions of 3.0 mm and 4.5 mm.' + M(2),
      a='<p>The specimen is <strong>necking</strong>: its cross-sectional area is reducing in one place, so the load it can carry falls as it continues to stretch, until it <strong>fractures</strong> at 4.5 mm.</p>'),
]
B += ASSIGN('task1', PEN, 'Task 1 &mdash; Load&ndash;extension graphs', T1, intro='<p class="notes-p" style="margin-bottom:6px;">A metal specimen was tested in a tensometer. The results are shown below.</p>' + mini(D.task_le(), 'Task 1: load&ndash;extension graph', 520))

# ================================================================ 2
B += H1('Properties of Materials')
B += P('Tensile tests let engineers compare materials and choose the right one for a job. The course specification lists six properties that you must be able to explain, recognise on a graph and use when choosing a material. Some of them come in opposite pairs, so learn them together.')
B += TABLE(['Property', 'What it means', 'On a load&ndash;extension graph', 'Example'], [
    ['<strong>Strength</strong>', 'The ability to resist a force without breaking. A material can be strong in <strong>tension</strong> (being pulled), in <strong>compression</strong> (being squashed), or both.', 'The highest point on the graph (the ultimate tensile load).', 'Mild steel, titanium alloy'],
    ['<strong>Elasticity</strong>', 'The ability to return to its original shape and size when the load is removed. The energy stored while it is stretched is given back.', 'The <strong>area under the elastic part</strong>: the larger the area, the more energy it can store and the more elastic it is.', 'Spring steel, a climbing rope'],
    ['<strong>Plasticity</strong>', 'The ability to be permanently deformed without breaking: it keeps its new shape when the load is removed. The energy used is absorbed, not given back.', 'The <strong>area under the plastic part</strong>: the larger the area, the more energy it absorbs and the more plastic it is.', 'Clay, a car crumple zone'],
    ['<strong>Ductility</strong>', 'The ability to be stretched a long way in tension without breaking, for example drawn out into a thin wire.', 'How far it stretches in the plastic region before it breaks.', 'Copper (electrical wire), mild steel'],
    ['<strong>Brittleness</strong>', 'Breaking suddenly, with little or no plastic deformation and no warning. The opposite of ductility.', 'Little or no plastic region: the graph ends suddenly, soon after the straight line.', 'Glass, cast iron, concrete'],
    ['<strong>Malleability</strong>', 'The ability to be shaped by hammering, pressing or rolling (compressive forming) without cracking.', 'Not shown: a tensile test pulls the material, and malleability is about squashing it.', 'Gold leaf, lead flashing, aluminium sheet'],
])
B += fig(D.areas(), 'Reading the properties of a material from its load&ndash;extension graph', 580)
B += KP('<strong>Ductile or plastic?</strong> They are related but not the same. <strong>Ductility</strong> is about <em>how far</em> a material stretches before it breaks; <strong>plasticity</strong> is about how much <em>energy</em> it absorbs as it deforms, which depends on how far it stretches <em>and</em> how much force it takes to do it. A material that stretches a long way under a small force is very ductile but absorbs little energy.')
B += KP('<strong>Ductile or malleable?</strong> Both describe a material that deforms plastically without breaking. <strong>Ductile</strong> is about being <em>stretched</em> (tension): wire drawing. <strong>Malleable</strong> is about being <em>squashed</em> into shape (compression): rolling, pressing, beating into sheet. Most metals are both, but not always to the same degree.')
B += H2('Sketching graphs for other materials')
B += P('You may be asked to sketch, on the same axes, a graph for a material with different properties. Two common ones:')
B += fig(D.sketches(), 'Sketching the graph of a more brittle material and of a less stiff material', 560)
B += SIMT('Demonstration 2 &mdash; comparing materials', 'material=mild_steel&mode=fe', HOW + '<p style="margin:0;"><strong>Try this:</strong> test mild steel, then choose cast iron and press <strong>+ Compare</strong>. Which is brittle, and how can you tell from the graph? Add aluminium alloy: compare the three for strength, stiffness and ductility. Then choose the <strong>Mystery Material</strong>, decide whether it is brittle, ductile or elastic, and use the buttons to check.</p>')
B += UL('A <strong>more brittle</strong> material: a straight line with little or no plastic region before it ends suddenly at fracture (like glass or cast iron).',
        'A <strong>less stiff</strong> material: a straight line from the origin with a <strong>lower gradient</strong>, because it stretches more for the same load. A stiffer material has a steeper line. In Section 5 you will measure stiffness with Young&rsquo;s modulus.')
T2 = [
 dict(key='hmat-t1a', q='a) Explain the difference between a <strong>ductile</strong> material and a <strong>malleable</strong> material, giving a product or situation that relies on each.' + M(2),
      a='<p>A ductile material can be stretched a long way in <strong>tension</strong> without breaking, so it can be drawn into wire, e.g. copper electrical cable. A malleable material can be shaped by <strong>compressive</strong> forces such as hammering, pressing or rolling without cracking, e.g. aluminium drinks cans pressed from sheet, lead flashing beaten to shape on a roof, or gold leaf.</p>', minh=80),
 dict(key='hmat-t1b', q='b) Explain the difference between <strong>elastic</strong> and <strong>plastic</strong> deformation. Give one product designed to deform elastically and one designed to deform plastically.' + M(3),
      a='<p>Elastic deformation is temporary: the material returns to its original shape and length when the load is removed, giving back the energy stored in it. Plastic deformation is permanent: the material keeps its new shape when the load is removed, and the energy is absorbed.</p><p>Elastic: a spring, a bungee cord, a car suspension spring, a climbing rope. Plastic: a car crumple zone (absorbs crash energy), a drinks can ring-pull, a crash barrier.</p>', minh=90),
 dict(key='hmat-t1e', q='c) A glass shelf and a mild steel shelf are both overloaded until they fail. Describe how the way each one fails would be different, and explain why.' + M(2),
      a='<p>The glass shelf would break <strong>suddenly</strong>, with no warning, because glass is brittle and has almost no plastic region. The mild steel shelf would bend and sag visibly (plastic deformation) before it failed, because mild steel is ductile. The visible bending gives a warning that it is overloaded.</p>', minh=70),
 dict(key='hmat-t2f', q='d) Describe the graph you would sketch, on the axes of the Task 1 graph, for a specimen of a <strong>more brittle</strong> material.' + M(1),
      a='<p>A straight line from the origin that ends suddenly (fracture) with little or no curved plastic region after it.</p>'),
 dict(key='hmat-t2g', q='e) Two specimens of the same size are tested. Specimen X stretches 40 mm before it breaks, under a maximum load of 2.0 kN. Specimen Y stretches 25 mm before it breaks, under a maximum load of 30 kN. State which specimen is more <strong>ductile</strong> and which is more <strong>plastic</strong>. Explain your answer.' + M(2),
      a='<p><strong>X is more ductile</strong>: it stretches further before it breaks. <strong>Y is more plastic</strong>: it needs a much larger force to deform it, so the area under its plastic region, the energy it absorbs, is much larger.</p>', minh=70),
]
B += ASSIGN('task2', PEN, 'Task 2 &mdash; Properties of materials', T2)

# ================================================================ 3
B += H1('Stress and Strain at Higher')
B += P('At National 5 you calculated stress and strain. Higher questions use exactly the same formulae, but the numbers are rarely handed to you directly: you will usually have to work out the cross-sectional area first, convert units, or rearrange the formula.')
B += FB('&sigma; = ' + fr('F', 'A') + ' &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &epsilon; = ' + fr('&Delta;l', 'l'))
B += UL('<strong>Stress</strong> (&sigma;) is the force per unit area inside a member. With force in N and area in mm<sup>2</sup>, stress is in <strong>' + N2 + '</strong>, which is the unit used in the data booklet table.',
        '<strong>Strain</strong> (&epsilon;) is the change in length divided by the original length. Both lengths must be in the <strong>same unit</strong>; they cancel, so strain has <strong>no unit</strong>. Strains are small, so they are often written in standard form, e.g. 0.00045 = 0.45 ' + m3 + ' = 4.5 &times; 10<sup>&minus;4</sup>.',
        'A tensile load makes a member longer; a compressive load makes it shorter. The formulae are the same for both.')
B += KP('<strong>Watch the units.</strong> Convert kN to N (&times; 1000) before calculating stress in ' + N2 + '. If you are given a <strong>mass</strong>, find the weight first: F = mg, with g = 9.8 ms<sup>&minus;2</sup>.')
B += H2('Finding the cross-sectional area')
B += P('The area is the area of the <strong>cross-section</strong>: the face you would see if you cut straight across the member. For a hollow member, subtract the hole.')
B += fig(D.sections(), 'Cross-sectional areas you need at Higher', 660)
At1 = pi * (42 ** 2 - 34 ** 2) / 4
B += WEL('Worked example 1 &mdash; stress in a tube', [
    ('Area of the tube', ['A = ' + fr('&pi;(D<sup>2</sup> &minus; d<sup>2</sup>)', '4') + ' = ' + fr('&pi; &times; (42<sup>2</sup> &minus; 34<sup>2</sup>)', '4'), 'A = ' + tr(At1) + ' mm<sup>2</sup>'], None),
    ('Stress', ['&sigma; = ' + fr('F', 'A') + ' = ' + fr('12 000', tr(At1)), '&sigma; = ' + F(sf(12000 / At1) + ' ' + N2)], None),
], intro='A tubular leg of a stage platform has an outside diameter of 42 mm and an inside diameter of 34 mm. It carries a compressive load of 12 kN. Calculate the stress in the leg.')
A1 = 9000 / 12; Ai = area(40); Ao = A1 + Ai; Do = math.sqrt(4 * Ao / pi)
B += WEL('Worked example 2 &mdash; working backwards to a wall thickness', [
    ('Area of metal needed', ['A = ' + fr('F', '&sigma;') + ' = ' + fr('9000', '12') + ' = ' + sf(A1, 3) + ' mm<sup>2</sup>'], None),
    ('Add the area of the hole to get the area of the outside circle', ['A<sub>hole</sub> = ' + fr('&pi; &times; 40<sup>2</sup>', '4') + ' = ' + tr(Ai) + ' mm<sup>2</sup>', 'A<sub>outside</sub> = 750 + ' + tr(Ai) + ' = ' + tr(Ao) + ' mm<sup>2</sup>'], None),
    ('Outside diameter', ['D = ' + SQ(fr('4A', '&pi;')) + ' = ' + SQ(fr('4 &times; ' + tr(Ao), '&pi;')) + ' = ' + tr(Do) + ' mm'], None),
    ('Wall thickness, th', ['th = ' + fr('D &minus; d', '2') + ' = ' + fr(tr(Do) + ' &minus; 40', '2'), 'th = ' + F(sf((Do - 40) / 2) + ' mm')], None),
], top=D.tube_thickness(), intro='A tube with an inside diameter of 40 mm must carry a compressive force of 9.0 kN, and the stress in it must be 12 ' + N2 + '. Calculate the wall thickness, th.')
B += WEL('Worked example 3 &mdash; rearranging the strain formula', [
    ('Rearrange', ['&epsilon; = ' + fr('&Delta;l', 'l') + ' &rarr; &Delta;l = &epsilon;l'], None),
    ('Substitute, with the length in mm', ['&Delta;l = 0.65 ' + m3 + ' &times; 4500', '&Delta;l = ' + F(sf(0.00065 * 4500) + ' mm')], None)],
   intro='A 4.5 m steel hanger is allowed a strain of 0.65 ' + m3 + '. Calculate the change in length.')
s3 = [
 ('a', 'A flat steel bar has a rectangular cross-section 25 mm &times; 10 mm and carries a tensile force of 18 kN. Calculate the stress in the bar.', 2, [ 'A = 25 &times; 10 = 250 mm<sup>2</sup>', '&sigma; = 18 000 &divide; 250 = 72 ' + N2], '72 ' + N2),
 ('b', 'A wire of diameter 3.0 mm carries a load of 250 N. Calculate the stress in the wire.', 2, ['A = &pi; &times; 3.0<sup>2</sup> &divide; 4 = ' + tr(area(3)) + ' mm<sup>2</sup>', '&sigma; = 250 &divide; ' + tr(area(3)) + ' = ' + tr(250 / area(3)) + ' ' + N2], sf(250 / area(3)) + ' ' + N2),
 ('c', 'A round bar must carry a tensile force of 12 kN without the stress exceeding 60 ' + N2 + '. Calculate the minimum diameter of the bar.', 3, ['A = 12 000 &divide; 60 = 200 mm<sup>2</sup>', 'd = &radic;(4 &times; 200 &divide; &pi;) = ' + tr(math.sqrt(800 / pi)) + ' mm'], sf(math.sqrt(800 / pi)) + ' mm'),
 ('d', 'A 15 m long cable stretches by 6.0 mm when it is loaded. Calculate the strain.', 1, ['&epsilon; = 6.0 &divide; 15 000 = 0.0004'], '4.0 &times; 10<sup>&minus;4</sup> (no units)'),
 ('e', 'A steel tube has an outside diameter of 60 mm and an inside diameter of 50 mm. It carries a compressive load of 20 kN. Calculate the stress.', 3, ['A = &pi;(60<sup>2</sup> &minus; 50<sup>2</sup>) &divide; 4 = ' + tr(pi * (3600 - 2500) / 4) + ' mm<sup>2</sup>', '&sigma; = 20 000 &divide; ' + tr(pi * 1100 / 4) + ' = ' + tr(20000 / (pi * 1100 / 4)) + ' ' + N2], sf(20000 / (pi * 1100 / 4)) + ' ' + N2),
 ('f', 'A mass of 1200 kg hangs from a hanger rod of diameter 16 mm. Calculate the stress in the rod.', 3, ['F = mg = 1200 &times; 9.8 = 11 760 N', 'A = &pi; &times; 16<sup>2</sup> &divide; 4 = ' + tr(area(16)) + ' mm<sup>2</sup>', '&sigma; = 11 760 &divide; ' + tr(area(16)) + ' = ' + tr(11760 / area(16)) + ' ' + N2], sf(11760 / area(16)) + ' ' + N2),
 ('g', 'During testing, a shaft shortened by 0.060 mm. The strain was 0.12 ' + m3 + '. Calculate the original length of the shaft.', 2, ['l = &Delta;l &divide; &epsilon; = 0.060 &divide; 0.00012 = 500 mm'], '500 mm (0.50 m)'),
]
T3 = [dict(key='hmat-t3' + k, q=k + ') ' + q + M(mk), a=C(*w) + F(fa), sym=SY) for k, q, mk, w, fa in s3]
B += ASSIGN('task3', PEN, 'Task 3 &mdash; Stress and strain', T3)

# ================================================================ 4
CA = D.compare_areas()
B += H1('Stress&ndash;Strain Graphs')
B += P('A load&ndash;extension graph describes one particular specimen: a thicker specimen of the same material would carry more load, and a longer one would stretch further. Dividing every load by the cross-sectional area (to get stress) and every extension by the original length (to get strain) removes the effect of the specimen&rsquo;s size. The result, a <strong>stress&ndash;strain graph</strong>, has the same shape but describes the <strong>material itself</strong>, so engineers can compare materials and use the values directly in design.')
B += fig(D.keypoints(), 'The key values read from a stress&ndash;strain graph', 560)
B += UL('<strong>Yield stress</strong> (&sigma;<sub>y</sub>): the stress at the yield point, the end of the elastic region. It is the greatest stress the material can take without being permanently deformed, and it is listed in the data booklet. Members in a structure are designed so that their working stress stays <strong>well below</strong> the yield stress, so they always behave elastically.',
        '<strong>Yield strain</strong>: the strain at the yield point, the greatest strain the material can take and still return to its original length.',
        '<strong>Ultimate tensile stress (UTS)</strong>: the highest stress on the graph, the greatest stress the material can withstand before it starts to neck and fail. It is also in the data booklet, and it is used to calculate factor of safety (Section 7).',
        'The <strong>gradient of the straight part</strong> shows how <strong>stiff</strong> the material is: the steeper the line, the stiffer the material, because it stretches less for the same stress. In Section 5 you will use this gradient to calculate Young&rsquo;s modulus.')
B += SIMT('Demonstration 3 &mdash; stress&ndash;strain graphs', 'material=aluminium_alloy&labels=1', HOW + '<p style="margin:0;"><strong>Try this:</strong> test aluminium alloy. The <strong>Material analysis</strong> panel gives its Young&rsquo;s modulus, yield stress and ultimate tensile stress: check them against the properties of materials table in the data booklet. Then change the <strong>C.S. area</strong> and test again. The loads change, but the stress&ndash;strain graph does not, because it describes the material, not the specimen.</p>')
B += H2('Comparing materials on one graph')
B += fig(D.compare(), 'Stress&ndash;strain graphs for four materials', 560)
B += TABLE(['To compare&hellip;', 'look at&hellip;', 'On the graph above'], [
    ['<strong>Strength</strong>', 'how high the graph goes (the UTS)', 'A is strongest, then B, C and D.'],
    ['<strong>Stiffness</strong>', 'the gradient of the straight part (steeper = stiffer)', 'A is stiffest; D is least stiff.'],
    ['<strong>Elasticity</strong>', 'the <strong>area under the elastic part</strong> of the graph: the strain energy the material can store and give back', 'B is the most elastic: it has the largest area under its elastic part.'],
    ['<strong>Plasticity</strong>', 'the <strong>area under the plastic part</strong> of the graph: the energy absorbed as the material deforms permanently', 'C is the most plastic by far. D stretches nearly as far as C, but at a much lower stress, so it absorbs much less energy.'],
    ['<strong>Ductility</strong>', 'how far the material stretches in the plastic region before it breaks', 'C and D are the most ductile.'],
    ['<strong>Brittleness</strong>', 'little or no plastic region, then a sudden end', 'A is brittle: it breaks at the end of its straight line.'],
])
B += P('So A behaves like glass or cast iron: strong and stiff but brittle. B is strong and stiff with a little ductility, like a high-strength alloy steel. C is a ductile metal such as mild steel. D has low strength and stiffness but stretches a very long way, like polythene (the plastic used for carrier bags).')
B += KP('<strong>Exam tip: compare.</strong> Questions often ask you to <em>describe the properties of one material in relation to another</em>. A mark is given for each <strong>comparison</strong>, so write sentences such as &ldquo;Material C is <strong>more ductile than</strong> material B&rdquo; or &ldquo;Material A is <strong>stronger than</strong> C&rdquo;. A bare statement such as &ldquo;C is ductile&rdquo; does not compare and may not gain the mark.')
T4 = [
 dict(key='hmat-t4a', q='a) State which material is the most brittle. Give a reason.' + M(1), a=F('P') + NOTE('It has no plastic region: it breaks at the end of its straight line.')),
 dict(key='hmat-t4b', q='b) State which material is the stiffest. Give a reason.' + M(1), a=F('P') + NOTE('Its straight part has the steepest gradient (the highest Young&rsquo;s modulus).')),
 dict(key='hmat-t4c', q='c) State which material is the most ductile.' + M(1), a=F('R') + NOTE('It stretches furthest in the plastic region, reaching a strain of 18 ' + m3 + ' before fracture.')),
 dict(key='hmat-t4d', q='d) State the yield stress of material Q.' + M(1), a=F('300 ' + N2)),
 dict(key='hmat-t4e', q='e) Describe <strong>three</strong> different properties of material R in relation to material P or material Q.' + M(3),
      a='<p>Any three, each a comparison: R is <strong>more ductile</strong> than P and Q (it stretches further before it breaks); R is <strong>less strong</strong> than P and Q (lower UTS); R is <strong>less stiff</strong> than P and Q (lower gradient); R is <strong>less elastic</strong> than P and Q (smaller area under its elastic part, so it stores less strain energy); R is <strong>more plastic</strong> than Q (larger area under its plastic part, so it absorbs more energy); R is <strong>less brittle</strong> than P.</p>', minh=90),
 dict(key='hmat-t4f', q='f) A designer needs a material for a crash barrier that must absorb a lot of energy by bending permanently without snapping. State which material is most suitable and justify your choice.' + M(2),
      a='<p><strong>R</strong>: it has the largest area under the plastic part of its graph, so it absorbs the most energy as it deforms permanently. P would snap suddenly because it is brittle.</p>'),
]
B += ASSIGN('task4', PEN, 'Task 4 &mdash; Stress&ndash;strain graphs', T4, intro='<p class="notes-p" style="margin-bottom:6px;">Three materials, P, Q and R, were tested. Their stress&ndash;strain graphs are shown below.</p>' + mini(D.task_ss3(), 'Task 4: stress&ndash;strain graphs for P, Q and R', 520))
