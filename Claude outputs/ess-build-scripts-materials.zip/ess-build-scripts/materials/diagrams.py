# -*- coding: utf-8 -*-
import math
from mlib import *

def _area(pts, x_from=None, x_to=None):
    """area under a polyline between x_from and x_to (trapezium rule)"""
    a = 0
    for (x1, y1), (x2, y2) in zip(pts, pts[1:]):
        if x_from is not None and x2 <= x_from: continue
        if x_to is not None and x1 >= x_to: continue
        a += (x2 - x1) * (y1 + y2) / 2
    return a

def EQC(cx, y, lhs, num, den, size=15, col=INK, after=''):
    """EQ centred on cx"""
    w = tw(lhs + ' = ', size) + 4 + max(tw(num, size), tw(den, size)) + 6 + (tw(after, size) + 6 if after else 0)
    return EQ(cx - w / 2, y, lhs, num, den, size, col, after)

# ---------------------------------------------------------------- load-extension, regions
def ductile_le():
    """ductile metal with a separate limit of proportionality A and yield point B"""
    A = (1.3, 3.4); Bp = (1.75, 3.9)
    pts = [(0, 0), A]
    for i in range(1, 21):
        t = i / 20
        pts.append((A[0] + (Bp[0] - A[0]) * t, A[1] + (Bp[1] - A[1]) * (1 - (1 - t) ** 2)))
    pts += curve(Bp[0], Bp[1], 5.2, 5.3, 8.6, 4.4)[2:]
    return pts, A, Bp

def regions():
    g = Graph(560, 340, 10, 6, 'extension (mm)', 'load (kN)', grid=False)
    pts, A, Bp = ductile_le()
    el = [p for p in pts if p[0] <= Bp[0] + 1e-9]
    g.fill(el + [(Bp[0], 0)], EL, 0.9)
    g.fill([p for p in pts if p[0] >= Bp[0] - 1e-9] + [(8.6, 0), (Bp[0], 0)], PL, 0.7)
    g.line(pts, BLUE)
    g.text(0.95, 0.6, 'elastic', size=11, col='#9a3412', weight=700)
    g.text(5.0, 1.6, 'plastic region', size=12, col=GREEN, weight=700)
    g.pt(0, 0, 'O', dx=-10, dy=16)
    g.pt(A[0], A[1], 'A', dx=-12, dy=2)
    g.pt(Bp[0], Bp[1], 'B', dx=-6, dy=-12)
    g.pt(5.2, 5.3, 'C', dy=-12)
    g.pt(8.6, 4.4, 'D', dx=12, dy=-6)
    g.text(7.9, 5.05, 'necking', size=11, col=MUTED, italic=True)
    # bracket under the axis: elastic O to B, plastic B to D
    y = g.y0 + 26
    g.add(L(g.X(0), y, g.X(Bp[0]), y, '#9a3412', 1.4) + L(g.X(0), y - 5, g.X(0), y + 5, '#9a3412', 1.4) + L(g.X(Bp[0]), y - 5, g.X(Bp[0]), y + 5, '#9a3412', 1.4))
    g.add(L(g.X(Bp[0]) + 3, y, g.X(8.6), y, GREEN, 1.4) + L(g.X(8.6), y - 5, g.X(8.6), y + 5, GREEN, 1.4))
    g.add(T(g.X(Bp[0] / 2), y + 16, 'O to B', size=11, col='#9a3412', weight=700) + T(g.X(5.2), y + 16, 'B to D', size=11, col=GREEN, weight=700))
    g.axes = g.axes.replace(T((g.x0 + g.x1) / 2, g.H - 8, 'extension (mm)', size=12, col=INK, weight=700), T(g.x1 - 40, g.y0 + 18, 'extension (mm)', size=12, col=INK, weight=700))
    return g.svg('Load-extension graph for a ductile metal, with points O, A, B, C and D')

def unload():
    g = Graph(560, 320, 10, 6, 'extension (mm)', 'load (kN)', grid=False)
    pts = curve(1.6, 4.0, 5.2, 5.3, 8.6, 4.4)
    g.line(pts, BLUE)
    g.add(ARROW(g.X(0.35), g.Y(0.55) - 12, g.X(0.85), g.Y(1.7) - 12, ORANGE, 1.6))
    g.add(ARROW(g.X(1.1), g.Y(2.1) + 8, g.X(0.6), g.Y(0.95) + 8, ORANGE, 1.6))
    g.text(4.3, 1.2, 'load and unload in the elastic', 'start', 11, '#9a3412', 700)
    g.text(4.3, 0.8, 'region: back to zero extension', 'start', 11, '#9a3412', 700)
    e = 3.4; s = [p for p in pts if p[0] >= e][0][1]
    g.pt(e, s, 'P', dy=-12, col=RED)
    set_ = e - s * 1.6 / 4.0
    g.line([(e, s), (set_, 0)], RED, 2.2, dash='7 5')
    g.add(ARROW(g.X(e) - 4, g.Y(s) + 30, g.X(e - 0.55) - 4, g.Y(s - 1.4) + 30, RED, 1.6))
    g.add(L(g.X(0), g.y0 + 30, g.X(set_), g.y0 + 30, RED, 1.4) + arrowhead(g.X(set_), g.y0 + 30, 0, RED, 7) + arrowhead(g.X(0), g.y0 + 30, 180, RED, 7))
    g.add(T((g.X(0) + g.X(set_)) / 2, g.y0 + 24, 'permanent set', size=11, col=RED, weight=700))
    g.text(e + 0.3, s - 1.6, 'unload from P: the line is', 'start', 11, RED, 700)
    g.text(e + 0.3, s - 2.0, 'parallel to the elastic line', 'start', 11, RED, 700)
    g.axes = g.axes.replace(T((g.x0 + g.x1) / 2, g.H - 8, 'extension (mm)', size=12, col=INK, weight=700), T(g.x1 - 40, g.y0 + 22, 'extension (mm)', size=12, col=INK, weight=700))
    return g.svg('Loading and unloading in the elastic and plastic regions')

def areas():
    """what each part of the graph tells you about a material's properties"""
    g = Graph(580, 350, 10, 6, 'extension', 'load', grid=False, mb=58)
    pts = curve(1.6, 4.0, 5.2, 5.3, 8.6, 4.4)
    g.fill([(0, 0), (1.6, 4.0), (1.6, 0)], EL, 0.95)
    g.fill(pts[1:] + [(8.6, 0), (1.6, 0)], PL, 0.7)
    g.line(pts, BLUE)
    g.add(ARROW(g.X(2.9), g.Y(1.05), g.X(1.1), g.Y(1.05), '#9a3412', 1.4))
    g.text(3.0, 1.15, 'area under the elastic part = energy stored', 'start', 11.5, '#9a3412', 700)
    g.text(3.0, 0.75, '→ elasticity', 'start', 11.5, '#9a3412', 700)
    g.text(5.0, 2.9, 'area under the plastic part', size=11.5, col=GREEN, weight=700)
    g.text(5.0, 2.5, '= energy absorbed → plasticity', size=11.5, col=GREEN, weight=700)
    g.add(L(g.x0 - 2, g.Y(5.3), g.X(5.2), g.Y(5.3), RED, 1.3, '5 4') + T(g.x0 + 4, g.Y(5.3) - 6, 'highest load → strength', 'start', 11.5, RED, 700))
    y = g.y0 + 22
    g.add(DIM(g.X(1.6), y, g.X(8.6), y, '', PURPLE) + T(g.X(5.1), y + 16, 'how far it stretches plastically before it breaks → ductility', size=11.5, col=PURPLE, weight=700))
    g.add(L(g.X(1.6), g.y0, g.X(1.6), y + 4, PURPLE, 1, '3 3') + L(g.X(8.6), g.Y(4.4), g.X(8.6), y + 4, PURPLE, 1, '3 3'))
    g.axes = g.axes.replace(T((g.x0 + g.x1) / 2, g.H - 8, 'extension', size=12, col=INK, weight=700), T(g.x1 - 30, g.y0 - 8, 'extension', size=12, col=INK, weight=700))
    return g.svg('Reading the properties of a material from its load-extension graph')

def sketches():
    g = Graph(560, 320, 10, 6, 'extension', 'load', grid=False)
    g.line(curve(1.6, 4.0, 5.2, 5.3, 8.6, 4.4), BLUE); g.text(8.75, 4.3, 'original', 'start', 11, BLUE, 700)
    g.line([(0, 0), (1.15, 4.6), (1.35, 4.75)], RED); g.add(dot(g.X(1.35), g.Y(4.75), RED, 3.5))
    g.text(1.5, 5.8, 'more brittle: little or no plastic region', 'start', 11, RED, 700)
    g.line(curve(2.8, 2.6, 6.0, 3.2, 8.0, 2.9), GREEN, dash='8 5'); g.text(8.15, 2.85, 'less stiff', 'start', 11, GREEN, 700)
    g.text(3.3, 1.5, 'lower gradient', 'start', 11, GREEN, 700)
    return g.svg('Sketching the graphs of a more brittle material and a less stiff material')

def keypoints():
    g = Graph(560, 330, 10, 6, 'strain, ε', 'stress, σ (Nmm<tspan baseline-shift="super" font-size="9">−2</tspan>)', grid=False)
    pts = curve(1.6, 4.0, 5.2, 5.3, 8.6, 4.4)
    g.line(pts, BLUE)
    g.hdash(4.0, 1.6, ORANGE, 'yield stress, σ' + '<tspan baseline-shift="sub" font-size="9">y</tspan>')
    g.vdash(1.6, 4.0, ORANGE)
    g.add(T(g.X(1.6), g.y0 + 17, 'yield strain', size=11, col=ORANGE, weight=700))
    g.hdash(5.3, 5.2, RED, 'ultimate tensile stress (UTS)')
    g.pt(1.6, 4.0, '', col=ORANGE); g.pt(5.2, 5.3, '', col=RED); g.pt(8.6, 4.4, 'fracture', dx=4, dy=-10, size=11)
    g.text(1.95, 2.3, 'gradient of the straight part', 'start', 11, BLUE, 700)
    g.text(1.95, 1.95, 'shows how stiff the material is', 'start', 11, BLUE, 700)
    return g.svg('Stress-strain graph showing yield stress, yield strain and ultimate tensile stress')

CMP = {'A': [(0, 0), (0.8, 5.2)],
       'B': curve(1.3, 4.0, 2.7, 4.6, 3.3, 4.4),
       'C': curve(1.4, 2.6, 5.6, 3.4, 9.0, 2.8),
       'D': curve(1.2, 0.55, 5.0, 0.95, 8.4, 0.8)}
CMP_Y = {'A': 0.8, 'B': 1.3, 'C': 1.4, 'D': 1.2}
def compare_areas():
    return {k: (round(_area(p, None, CMP_Y[k]), 2), round(_area(p, CMP_Y[k], None), 2), p[-1][0]) for k, p in CMP.items()}

def compare():
    g = Graph(560, 340, 10, 6, 'strain, ε', 'stress, σ', grid=False)
    col = {'A': RED, 'B': ORANGE, 'C': GREEN, 'D': PURPLE}
    for k, p in CMP.items(): g.line(p, col[k])
    g.text(1.05, 5.25, 'A', 'start', 14, RED, 700)
    g.text(3.45, 4.45, 'B', 'start', 14, ORANGE, 700)
    g.text(9.15, 2.75, 'C', 'start', 14, GREEN, 700)
    g.text(8.55, 0.75, 'D', 'start', 14, PURPLE, 700)
    return g.svg('Stress-strain graphs for four materials A, B, C and D')

def strain_energy():
    g = Graph(520, 300, 10, 6, 'extension, x', 'force, F', grid=False)
    pts = curve(1.8, 4.2, 5.2, 5.3, 8.4, 4.6)
    g.fill([(0, 0), (1.3, 1.3 * 4.2 / 1.8), (1.3, 0)], BLUE, 0.22)
    g.line(pts, BLUE)
    F_ = 1.3 * 4.2 / 1.8
    g.hdash(F_, 1.3, INK, None); g.vdash(1.3, F_, INK, None)
    g.add(T(g.x0 - 8, g.Y(F_) + 4, 'F', 'end', 13, INK, 700)); g.add(T(g.X(1.3), g.y0 + 18, 'x', size=13, weight=700))
    g.text(0.85, 0.55, 'E', 'middle', 13, BLUE, 700); g.add(T(g.X(0.85) + 9, g.Y(0.55) + 4, 's', 'start', 9, BLUE, 700))
    g.text(2.6, 2.0, 'shaded area = ½ × F × x = strain energy', 'start', 12, BLUE, 700)
    return g.svg('Strain energy is the area under the elastic part of a force-extension graph')

# ---------------------------------------------------------------- task / exam graphs (gridded)
def task_le():
    """load-extension graph used in Task 1 (and again in Task 6): elastic to 30 kN at 1.0 mm"""
    g = Graph(560, 360, 5, 50, 'extension (mm)', 'load (kN)', xt=[0, 0.5, 1, 1.5, 2, 2.5, 3, 3.5, 4, 4.5, 5], yt=[0, 10, 20, 30, 40, 50], minor=(0.25, 5))
    g.line(curve(1.0, 30, 3.0, 45, 4.5, 38), BLUE)
    return g.svg('Load-extension graph for Task 1')

TSS = {'P': [(0, 0), (2.0, 400)], 'Q': curve(2.0, 300, 7.0, 380, 9.0, 360), 'R': curve(3.0, 150, 12.0, 220, 18.0, 170)}
TSS_Y = {'P': 2.0, 'Q': 2.0, 'R': 3.0}
def task_ss3_areas():
    return {k: (round(_area(p, None, TSS_Y[k])), round(_area(p, TSS_Y[k], None))) for k, p in TSS.items()}

def task_ss3():
    """three materials for comparing properties (Task 4)"""
    g = Graph(560, 360, 20, 500, 'strain (× 10<tspan baseline-shift="super" font-size="9">−3</tspan>)', 'stress (Nmm<tspan baseline-shift="super" font-size="9">−2</tspan>)', xt=[0, 2, 4, 6, 8, 10, 12, 14, 16, 18, 20], yt=[0, 100, 200, 300, 400, 500], minor=(1, 50))
    g.line(TSS['P'], RED); g.text(2.4, 410, 'P', 'start', 14, RED, 700)
    g.line(TSS['Q'], ORANGE); g.text(9.3, 360, 'Q', 'start', 14, ORANGE, 700)
    g.line(TSS['R'], GREEN); g.text(18.3, 165, 'R', 'start', 14, GREEN, 700)
    return g.svg('Stress-strain graph for materials P, Q and R')

def task_e():
    g = Graph(520, 340, 8, 300, 'strain (× 10<tspan baseline-shift="super" font-size="9">−3</tspan>)', 'stress (Nmm<tspan baseline-shift="super" font-size="9">−2</tspan>)', xt=[0, 1, 2, 3, 4, 5, 6, 7, 8], yt=[0, 50, 100, 150, 200, 250, 300], minor=(0.5, 25))
    g.line(curve(2.5, 275, 5.2, 294, 7.6, 280), BLUE)   # E = 110 kNmm-2
    return g.svg('Stress-strain graph for Task 5')

def exam_ss():
    g = Graph(560, 360, 14, 350, 'strain (× 10<tspan baseline-shift="super" font-size="9">−3</tspan>)', 'stress (Nmm<tspan baseline-shift="super" font-size="9">−2</tspan>)', xt=list(range(0, 15, 2)), yt=[0, 50, 100, 150, 200, 250, 300, 350], minor=(1, 10))
    g.line(curve(250 / 70, 250, 9.0, 300, 12.5, 270), BLUE)
    return g.svg('Stress-strain graph for exam question 1')

def worked_e():
    g = Graph(500, 320, 8, 300, 'strain (× 10<tspan baseline-shift="super" font-size="9">−3</tspan>)', 'stress (Nmm<tspan baseline-shift="super" font-size="9">−2</tspan>)', xt=[0, 1, 2, 3, 4, 5, 6, 7, 8], yt=[0, 50, 100, 150, 200, 250, 300], minor=(0.5, 25))
    g.line(curve(250 / 100, 250, 5.0, 285, 7.5, 260), BLUE)
    g.hdash(200, 2.0, RED); g.vdash(2.0, 200, RED); g.pt(2.0, 200, '', col=RED)
    g.text(2.2, 188, '(2.0 × 10⁻³, 200)', 'start', 11, RED, 700)
    return g.svg('Reading a point on the linear part of the graph to find Young’s modulus')

# ---------------------------------------------------------------- cross-sections
def sections():
    W, H = 660, 240; cy = 92
    b = ''
    cx = 110
    b += '<circle cx="%d" cy="%d" r="46" fill="#cbd5e1" stroke="%s" stroke-width="2"/>' % (cx, cy, INK)
    b += DIM(cx - 46, cy, cx + 46, cy, 'd', RED, 14)
    b += T(cx, 160, 'solid round bar', size=13, weight=700) + EQC(cx, 196, 'A', 'πd²', '4', 16, BLUE)
    cx = 330
    b += RING(cx, cy, 46, 33)
    b += DIM(cx - 46, cy - 54, cx + 46, cy - 54, 'D (outside)', RED, 12)
    b += DIM(cx - 33, cy, cx + 33, cy, 'd (inside)', GREEN, 11)
    b += T(cx, 160, 'hollow tube', size=13, weight=700) + EQC(cx, 196, 'A', 'π(D² − d²)', '4', 16, BLUE)
    cx = 555
    b += SQRING(cx, cy, 88, 68)
    b += DIM(cx - 44, cy - 54, cx + 44, cy - 54, 'outside', RED, 12)
    b += DIM(cx - 34, cy, cx + 34, cy, 'inside', GREEN, 11)
    b += T(cx, 160, 'square hollow section', size=13, weight=700) + T(cx, 202, 'A = outside² − inside²', size=15, col=BLUE, weight=700)
    return svg(W, H, b, 'Cross-sectional areas of a solid bar, a tube and a hollow section')

def tube_thickness():
    W, H = 340, 170; cx, cy = 140, 84
    b = RING(cx, cy, 62, 48)
    b += DIM(cx - 48, cy, cx + 48, cy, 'Ø 40 mm', GREEN, 13)
    b += ARROW(cx + 20, cy + 40, cx + 46, cy + 30, RED, 1.4) if False else ''
    # wall thickness: arrows pointing in at the wall from both sides
    b += ARROW(cx + 26, cy + 26, cx + 48 * 0.7071, cy + 48 * 0.7071, RED, 1.4) + ARROW(cx + 86, cy + 86, cx + 62 * 0.7071, cy + 62 * 0.7071, RED, 1.4)
    b += T(cx + 92, cy + 80, 'th = ?', 'start', 14, RED, 700)
    return svg(W, H, b, 'Tube with a 40 mm inside diameter and unknown wall thickness th')

# ---------------------------------------------------------------- factor of safety scale
def fos_scale():
    W, H = 560, 250
    x = 130; y0 = 220; top = 30
    def Y(s): return y0 - (y0 - top) * s / 430
    b = '<rect x="%d" y="%s" width="36" height="%s" fill="#f1f5f9" stroke="%s"/>' % (x, f(Y(430)), f(y0 - Y(430)), INK)
    b += '<rect x="%d" y="%s" width="36" height="%s" fill="#bbf7d0"/>' % (x, f(Y(86)), f(y0 - Y(86)))
    b += '<rect x="%d" y="%s" width="36" height="%s" fill="#fed7aa" fill-opacity="0.6"/>' % (x, f(Y(220)), f(Y(86) - Y(220)))
    for s, lab, col in [(430, 'ultimate tensile stress 430 Nmm⁻²', RED), (220, 'yield stress 220 Nmm⁻²', ORANGE), (86, 'safe working stress 86 Nmm⁻²', GREEN)]:
        b += L(x - 8, Y(s), x + 44, Y(s), col, 2) + T(x + 54, Y(s) + 4, lab, 'start', 12, col, 700)
    b += T(x - 14, y0 + 4, '0', 'end', 11, MUTED)
    b += T(x + 18, y0 + 22, 'mild steel', size=11, col=MUTED, weight=700)
    b += EQC(440, 140, 'FoS', '430', '86', 16, BLUE, '= 5.0')
    b += T(440, 182, 'working stress stays well', 'middle', 11, MUTED) + T(440, 196, 'inside the elastic region', 'middle', 11, MUTED)
    return svg(W, H, b, 'Safe working stress compared with yield stress and UTS')

# ---------------------------------------------------------------- tensometer and test pieces
def tensometer():
    W, H = 580, 370; cx = 200
    b = ''
    b += RECT(50, 296, 300, 56, '#cbd5e1', rx=6)                                           # base
    b += RECT(70, 306, 132, 34, '#0f172a', rx=4) + T(78, 320, '12.4 kN', 'start', 12, '#4ade80', 700) + T(78, 334, '0.85 mm', 'start', 12, '#4ade80', 700)
    b += '<circle cx="250" cy="323" r="9" fill="#16a34a"/><circle cx="280" cy="323" r="9" fill="#dc2626"/>'
    b += RECT(78, 40, 18, 256, '#e2e8f0') + RECT(304, 40, 18, 256, '#e2e8f0')            # columns
    b += RECT(62, 36, 276, 34, '#94a3b8', rx=4)                                            # fixed crosshead
    b += RECT(cx - 26, 70, 52, 18, '#64748b')                                              # load cell
    b += RECT(cx - 16, 88, 32, 36, '#475569')                                              # upper grip
    b += RECT(cx - 16, 214, 32, 36, '#475569')                                             # lower grip
    sp = [(cx - 9, 118), (cx + 9, 118), (cx + 9, 136), (cx + 5, 146), (cx + 5, 186), (cx + 9, 196), (cx + 9, 220), (cx - 9, 220), (cx - 9, 196), (cx - 5, 186), (cx - 5, 146), (cx - 9, 136)]
    b += '<polygon points="%s" fill="#e5e7eb" stroke="%s" stroke-width="1.6"/>' % (' '.join('%s,%s' % p for p in sp), INK)
    b += RECT(cx - 16, 88, 32, 36, '#475569') + RECT(cx - 16, 214, 32, 36, '#475569')     # grips drawn over the ends
    b += L(cx - 5, 152, cx - 22, 152, ORANGE, 2) + L(cx - 5, 180, cx - 22, 180, ORANGE, 2) + RECT(cx - 34, 148, 12, 36, '#fdba74', ORANGE, 1.4)   # extensometer
    b += RECT(62, 250, 276, 26, '#94a3b8', rx=4)                                           # moving crosshead
    b += ARROW(330, 262, 330, 290, RED, 2.4)
    labels = [(53, 'fixed crosshead', 338), (79, 'load cell: measures the force', cx + 26), (106, 'upper grip', cx + 16), (166, 'test specimen', cx + 9),
              (232, 'lower grip', cx + 16), (263, 'moving crosshead pulls down', 338), (323, 'display: load and extension', 202)]
    for y, s, x0 in labels:
        b += L(x0 + 4, y, 372, y, MUTED, 1) + T(378, y + 4, s, 'start', 12, INK, 700)
    b += L(cx - 34, 166, 44, 166, MUTED, 1) + T(40, 160, 'extensometer:', 'end', 11, ORANGE, 700) + T(40, 174, 'measures extension', 'end', 11, ORANGE, 700)
    b = '<g transform="translate(110,0)">' + b + '</g>'
    return svg(W + 110, H, b, 'A tensometer: a specimen is gripped and pulled apart while the load and extension are measured')

def test_pieces():
    W, H = 640, 270
    def piece(x0, x1, y, gl, gr, neck=None, name=''):
        h_end, h_g = 16, 9
        top = [(x0, y - h_end), (x0 + 80, y - h_end), (x0 + 110, y - h_g)]
        if neck: top += [(neck - 26, y - h_g), (neck, y - 4)]
        else: top += [(x1 - 110, y - h_g)]
        return top
    b = ''
    # new round test piece
    y = 64; x0, x1 = 40, 600
    outline = [(x0, y - 18), (x0 + 90, y - 18), (x0 + 125, y - 10), (x1 - 125, y - 10), (x1 - 90, y - 18), (x1, y - 18),
               (x1, y + 18), (x1 - 90, y + 18), (x1 - 125, y + 10), (x0 + 125, y + 10), (x0 + 90, y + 18), (x0, y + 18)]
    b += '<polygon points="%s" fill="#e5e7eb" stroke="%s" stroke-width="1.8"/>' % (' '.join('%s,%s' % p for p in outline), INK)
    for xx in range(x0 + 6, x0 + 88, 7): b += L(xx, y - 18, xx - 4, y + 18, '#94a3b8', 1)
    for xx in range(x1 - 86, x1 - 2, 7): b += L(xx, y - 18, xx - 4, y + 18, '#94a3b8', 1)
    g1, g2 = 220, 420
    b += L(g1, y - 14, g1, y + 14, ORANGE, 2) + L(g2, y - 14, g2, y + 14, ORANGE, 2)
    b += DIM(g1, y - 30, g2, y - 30, 'gauge length', ORANGE, 12)
    b += T(x0, 20 + 0, 'new test piece', 'start', 13, INK, 700)
    b += T(x0 + 45, y + 36, 'threaded end (gripped)', 'middle', 11, MUTED, 700) + T(320, y + 30, 'narrower, accurately machined middle', 'middle', 11, MUTED, 700)
    # broken test piece: stretched, necked and fractured
    y = 190; fx = 330
    left = [(x0, y - 18), (x0 + 90, y - 18), (x0 + 125, y - 9), (fx - 40, y - 8), (fx - 12, y - 4), (fx - 2, y - 5), (fx + 2, y), (fx - 2, y + 5), (fx - 12, y + 4), (fx - 40, y + 8), (x0 + 125, y + 9), (x0 + 90, y + 18), (x0, y + 18)]
    right = [(fx + 8, y - 5), (fx + 4, y), (fx + 8, y + 5), (fx + 18, y + 4), (fx + 46, y + 8), (x1 - 105, y + 9), (x1 - 70, y + 18), (x1 + 20, y + 18),
             (x1 + 20, y - 18), (x1 - 70, y - 18), (x1 - 105, y - 9), (fx + 46, y - 8), (fx + 18, y - 4)]
    for poly in (left, right):
        b += '<polygon points="%s" fill="#e5e7eb" stroke="%s" stroke-width="1.8"/>' % (' '.join('%s,%s' % p for p in poly), INK)
    for xx in range(x0 + 6, x0 + 88, 7): b += L(xx, y - 18, xx - 4, y + 18, '#94a3b8', 1)
    for xx in range(x1 - 66, x1 + 18, 7): b += L(xx, y - 18, xx - 4, y + 18, '#94a3b8', 1)
    h1, h2 = 220, 446
    b += L(h1, y - 13, h1, y + 13, ORANGE, 2) + L(h2, y - 13, h2, y + 13, ORANGE, 2)
    b += DIM(h1, y - 30, h2, y - 30, 'gauge length has increased', ORANGE, 12)
    b += T(x0, 140, 'after the test', 'start', 13, INK, 700)
    b += L(fx - 20, y + 10, fx - 52, y + 46, MUTED, 1) + T(fx - 56, y + 58, 'necking', 'end', 12, RED, 700)
    b += L(fx + 3, y + 8, fx + 30, y + 46, MUTED, 1) + T(fx + 34, y + 58, 'fracture', 'start', 12, RED, 700)
    return svg(W, H + 10, b, 'A new test piece, and a test piece that has been pulled until it necked and fractured')

# ---------------------------------------------------------------- bolts that are already tightened
def bolts():
    W, H = 720, 300
    b = ''
    # left: bracket bolted under a beam
    b += HATCH(40, 300, 26, down=False) + RECT(40, 26, 260, 34, '#cbd5e1')                    # beam
    b += T(170, 47, 'roof beam', 'middle', 11, MUTED, 700)
    b += RECT(80, 60, 180, 14, '#94a3b8')                                                    # bracket flange
    b += RECT(160, 74, 20, 96, '#94a3b8')                                                    # bracket stem
    b += '<circle cx="170" cy="170" r="10" fill="#94a3b8" stroke="%s" stroke-width="1.6"/>' % INK
    b += ARROW(170, 182, 170, 236, RED, 2.6) + T(178, 232, 'load', 'start', 12, RED, 700)
    for x in (110, 230):
        # bolt = head + threaded shank (one piece, light steel); nut = separate darker hexagon screwed onto the shank
        b += RECT(x - 8, 20, 16, 80, '#e2e8f0', INK, 1.6)                                    # shank
        for yy in range(78, 99, 4): b += L(x - 8, yy, x + 8, yy + 2, '#94a3b8', 1)          # thread
        b += RECT(x - 15, 8, 30, 12, '#cbd5e1', INK, 1.6, 2)                                  # bolt head
        b += L(x - 5, 8, x - 5, 20, '#94a3b8', 1) + L(x + 5, 8, x + 5, 20, '#94a3b8', 1)    # hex faces
        b += RECT(x - 15, 74, 30, 14, '#475569', INK, 1.6, 2)                                 # nut
        b += L(x - 5, 74, x - 5, 88, '#94a3b8', 1) + L(x + 5, 74, x + 5, 88, '#94a3b8', 1)  # hex faces
        # tension inside the bolt: arrows pointing inwards, as for a tie
        b += ARROW(x, 25, x, 43, PURPLE, 1.8) + ARROW(x, 69, x, 51, PURPLE, 1.8)
    # labels for the right-hand bolt
    b += L(246, 14, 320, 14, MUTED, 1) + T(324, 18, 'bolt head', 'start', 12, INK, 700)
    b += L(239, 96, 320, 110, MUTED, 1) + T(324, 114, 'bolt: threaded shank', 'start', 12, INK, 700)
    b += L(246, 81, 320, 81, MUTED, 1) + T(324, 85, 'nut', 'start', 12, INK, 700)
    b += L(236, 34, 320, 47, PURPLE, 1) + T(324, 51, 'arrows inside the bolt:', 'start', 11, PURPLE, 700) + T(324, 65, 'it is in tension', 'start', 11, PURPLE, 700)
    b += T(40, 262, 'Tightening the nut stretches each bolt, so it', 'start', 12, PURPLE, 700)
    b += T(40, 278, 'is already in tension before the load is added.', 'start', 12, PURPLE, 700)
    # right: stress in one bolt, on a condensed scale (not to scale) that reaches the UTS
    x, w = 470, 46; y0 = 266
    yt, ysw, yuts = y0 - 9, 168, 44        # top of the tightening band, safe working stress line, UTS line
    b += RECT(x, yuts, w, y0 - yuts, '#f1f5f9', INK, 1.2)
    b += RECT(x, yt, w, y0 - yt, '#c4b5fd', PURPLE, 1.2)
    b += RECT(x, ysw, w, yt - ysw, '#bbf7d0', GREEN, 1.2)
    b += L(x - 10, ysw, x + w + 10, ysw, RED, 2.2) + L(x - 10, yuts, x + w + 10, yuts, INK, 2.2)
    b += T(x + w + 14, yuts + 4, 'ultimate stress (UTS) 430', 'start', 12, INK, 700)
    b += T(x + w + 14, (yuts + ysw) / 2 + 4, 'the safety margin', 'start', 12, MUTED, 700)
    b += T(x + w + 14, ysw - 12, 'safe working stress', 'start', 12, RED, 700) + EQ(x + w + 14, ysw + 12, '', '430', '4.0', 12, RED, '= 107.5')
    b += T(x + w + 14, (ysw + yt) / 2 + 14, '107.5 \u2212 8.0 = 99.5', 'start', 12, GREEN, 700) + T(x + w + 14, (ysw + yt) / 2 + 29, 'left for the load', 'start', 12, GREEN, 700)
    b += T(x + w + 14, y0 - 5, '8.0 from tightening', 'start', 12, PURPLE, 700)
    b += T(x - 12, y0 + 4, '0', 'end', 11, MUTED) + T(x + w / 2, y0 + 20, 'stress in one bolt (Nmm\u207b\u00b2), not to scale', 'middle', 11, INK, 700)
    return svg(W, H + 10, b, 'A bracket held by pre-tightened bolts, and how the safe working stress in a bolt is shared')

# ---------------------------------------------------------------- strain gauges
FOIL = '#b45309'
def foil(x, y, w, h, rows=8, horizontal=True, tabs=True, backing=True):
    """a foil gauge: ONE continuous track that zig-zags from one contact pad to the other.
    The long runs lie along the sensitive direction (horizontal or vertical). rows is made even so both ends
    of the track finish at the same end, next to the two contact pads."""
    rows = max(2, rows + rows % 2)
    s = RECT(x, y, w, h, '#fef9c3', '#a16207', 1.4, 5) if backing else ''
    tw_ = max(1.6, min(w, h) / 30)
    if horizontal:
        x1, x2 = x + w * 0.24, x + w * 0.92
        ys = [y + h * 0.14 + i * (h * 0.72) / (rows - 1) for i in range(rows)]
        pts = []
        for i, yy in enumerate(ys): pts += [(x1, yy), (x2, yy)] if i % 2 == 0 else [(x2, yy), (x1, yy)]
        if tabs:
            px, pw = x + w * 0.04, w * 0.12
            pads = [(ys[0], y + h * 0.06), (ys[-1], y + h * 0.94 - h * 0.22)]
            pts = [(px + pw, ys[0])] + pts + [(px + pw, ys[-1])]
            s += path(pts, FOIL, tw_)
            s += RECT(px, y + h * 0.06, pw, h * 0.3, FOIL, FOIL, 1, 2) + RECT(px, y + h * 0.64, pw, h * 0.3, FOIL, FOIL, 1, 2)
        else:
            s += path(pts, FOIL, tw_)
    else:
        y1, y2 = y + h * 0.24, y + h * 0.92
        xs = [x + w * 0.14 + i * (w * 0.72) / (rows - 1) for i in range(rows)]
        pts = []
        for i, xx in enumerate(xs): pts += [(xx, y1), (xx, y2)] if i % 2 == 0 else [(xx, y2), (xx, y1)]
        if tabs:
            py, ph = y + h * 0.04, h * 0.12
            pts = [(xs[0], py + ph)] + pts + [(xs[-1], py + ph)]
            s += path(pts, FOIL, tw_)
            s += RECT(x + w * 0.06, py, w * 0.3, ph, FOIL, FOIL, 1, 2) + RECT(x + w * 0.64, py, w * 0.3, ph, FOIL, FOIL, 1, 2)
        else:
            s += path(pts, FOIL, tw_)
    return s

def gauge():
    """one foil gauge, pulled in tension along its long runs"""
    W, H = 600, 230
    gx, gy, gw, gh = 185, 46, 230, 110
    b = foil(gx, gy, gw, gh, rows=8)
    b += T(gx + gw / 2, 30, 'foil grid on a thin backing', size=12, weight=700)
    cy = gy + gh / 2
    b += ARROW(gx - 40, cy, gx - 110, cy, RED, 2.6) + T(gx - 75, cy - 12, 'tension', size=12, col=RED, weight=700)
    b += ARROW(gx + gw + 40, cy, gx + gw + 110, cy, RED, 2.6) + T(gx + gw + 75, cy - 12, 'tension', size=12, col=RED, weight=700)
    b += DIM(gx + 46, 176, gx + gw - 18, 176, '', MUTED) + T(gx + gw / 2, 196, 'sensitive direction: along the long runs', size=12, col=MUTED, weight=700)
    b += T(gx + gw / 2, 220, 'in tension the tracks get longer and thinner, so the resistance increases', size=12, col=RED, weight=700)
    return svg(W, H, b, 'A foil strain gauge pulled in tension along its long runs')

def gauge_positions():
    W, H = 660, 320
    b = RECT(70, 46, 520, 84, '#cbd5e1', INK, 1.8, 3)
    b += ARROW(70, 88, 24, 88, RED, 2.6) + ARROW(590, 88, 636, 88, RED, 2.6) + T(30, 76, 'F', 'middle', 13, RED, 700) + T(630, 76, 'F', 'middle', 13, RED, 700)
    b += T(330, 38, 'tie bar in tension', 'middle', 12, INK, 700)
    b += foil(130, 58, 140, 60, rows=6)                       # active: runs along the load
    b += foil(400, 54, 60, 68, rows=6, horizontal=False)      # passive option 1: runs across the load
    b += L(200, 118, 200, 152, MUTED, 1) + T(70, 166, 'active gauge: long runs lined up with', 'start', 12, RED, 700) + T(70, 182, 'the load, so it stretches with the bar', 'start', 12, RED, 700)
    b += L(430, 122, 430, 152, MUTED, 1) + T(360, 166, 'passive gauge, option 1: at 90\u00b0', 'start', 12, BLUE, 700) + T(360, 182, 'to the load, so it is hardly strained', 'start', 12, BLUE, 700)
    b += RECT(360, 206, 230, 50, '#e2e8f0', INK, 1.4, 3) + foil(420, 211, 120, 40, rows=6)
    b += T(360, 276, 'passive gauge, option 2: on an unloaded piece of', 'start', 12, BLUE, 700) + T(360, 292, 'the same material, next to the bar (no load on it)', 'start', 12, BLUE, 700)
    b += T(70, 230, 'Either way, the passive gauge is at the', 'start', 12, INK, 700) + T(70, 246, 'same temperature as the active gauge,', 'start', 12, INK, 700) + T(70, 262, 'but the load does not stretch it.', 'start', 12, INK, 700)
    return svg(W, H, b, 'Where to put the active and passive strain gauges')

def gauge_circuit():
    """active and passive gauges in two voltage dividers; each divider output is at the same height as the
    op-amp input it feeds, so the input wires run straight across with no bends"""
    W, H = 660, 300
    top, bot = 40, 260
    yi, yn = 125, 185            # inverting (-) and non-inverting (+) input heights = divider outputs
    b = L(40, top, 610, top, INK, 1.6) + T(40, top - 10, '+5.0 V', 'start', 12, INK, 700)
    b += L(40, bot, 610, bot, INK, 1.6) + T(40, bot + 20, '0 V', 'start', 12, INK, 700)
    def res(x, y1, y2, mid, lab='', col=INK, fill='white', side='end'):
        """vertical resistor from y1 to y2 with its body centred on mid"""
        return (L(x, y1, x, mid - 26, INK, 1.6) + RECT(x - 10, mid - 26, 20, 52, fill, col, 1.8) + L(x, mid + 26, x, y2, INK, 1.6) +
                (T(x - 16 if side == 'end' else x + 16, mid + 4, lab, side, 12, col, 700) if lab else ''))
    # divider 1: passive gauge B at the bottom, output V1 at the height of the - input
    b += res(110, top, yi, 80, '1.0 k\u03a9') + res(110, yi, bot, 196, 'B (passive)', BLUE, '#dbeafe') + dot(110, yi, INK, 3.5)
    # divider 2: active gauge A at the bottom, output V2 at the height of the + input
    b += res(220, top, yn, 76, '1.0 k\u03a9', side='start') + res(220, yn, bot, 222, 'A (active)', RED, '#fee2e2', 'start') + dot(220, yn, INK, 3.5)
    # op-amp
    ox, oy = 440, 155
    b += '<polygon points="%d,%d %d,%d %d,%d" fill="white" stroke="%s" stroke-width="2"/>' % (ox, oy - 60, ox, oy + 60, ox + 100, oy, INK)
    b += T(ox + 13, yi + 6, '\u2212', 'middle', 18, INK, 700) + T(ox + 13, yn + 6, '+', 'middle', 18, INK, 700)
    # straight input wires through R1 (the - wire crosses divider 2's plain wire: no dot, so no connection)
    b += L(110, yi, 310, yi) + RECT(310, yi - 7, 46, 14, 'white', INK, 1.6) + T(333, yi - 12, 'R<tspan baseline-shift="sub" font-size="9">i</tspan>', 'middle', 12, INK, 700) + L(356, yi, ox, yi)
    b += L(220, yn, 310, yn) + RECT(310, yn - 7, 46, 14, 'white', INK, 1.6) + T(333, yn + 24, 'R<tspan baseline-shift="sub" font-size="9">i</tspan>', 'middle', 12, INK, 700) + L(356, yn, ox, yn)
    # Rf from + input to 0 V, and Rf feedback from - input to the output
    b += dot(395, yn, INK, 3) + L(395, yn, 395, 205) + RECT(388, 205, 14, 32, 'white', INK, 1.6) + L(395, 237, 395, bot) + T(408, 226, 'R<tspan baseline-shift="sub" font-size="9">f</tspan>', 'start', 12, INK, 700) + dot(395, bot, INK, 3)
    b += dot(395, yi, INK, 3) + L(395, yi, 395, 70) + L(395, 70, 480, 70) + RECT(480, 63, 46, 14, 'white', INK, 1.6) + T(503, 58, 'R<tspan baseline-shift="sub" font-size="9">f</tspan>', 'middle', 12, INK, 700) + L(526, 70, 575, 70) + L(575, 70, 575, oy) + dot(575, oy, INK, 3)
    b += L(ox + 100, oy, 610, oy) + T(614, oy + 5, 'V<tspan baseline-shift="sub" font-size="9">out</tspan>', 'start', 13, INK, 700)
    b += T(118, yi - 8, 'V<tspan baseline-shift="sub" font-size="9">1</tspan>', 'start', 12, BLUE, 700)
    b += T(228, yn - 8, 'V<tspan baseline-shift="sub" font-size="9">2</tspan>', 'start', 12, RED, 700)
    return svg(W, H, b, 'Active and passive strain gauges in two voltage dividers feeding a difference amplifier')

def gangway():
    W, H = 560, 230
    b = RECT(0, 168, 560, 62, WATER, WATER, 0)
    b += RECT(20, 120, 170, 110, '#d6d3d1', INK, 1.6) + HATCH(20, 190, 120, down=True) + T(105, 160, 'pier', 'middle', 12, INK, 700)
    hull = [(330, 70), (560, 70), (560, 200), (360, 200)]
    b += '<polygon points="%s" fill="#e2e8f0" stroke="%s" stroke-width="1.8"/>' % (' '.join('%s,%s' % p for p in hull), INK)
    b += RECT(380, 40, 160, 30, '#f8fafc', INK, 1.4) + T(470, 140, 'ferry', 'middle', 12, INK, 700)
    for i in range(5): b += RECT(395 + i * 28, 48, 16, 12, '#93c5fd', INK, 1)
    b += L(180, 120, 345, 72, INK, 4)
    b += L(180, 96, 345, 48, INK, 1.6)
    for i in range(6):
        x = 190 + i * 30; y = 120 - (x - 180) * 48 / 165
        b += L(x, y - 2, x, y - 24, INK, 1.4)
    b += T(250, 72, 'gangway', 'middle', 12, BLUE, 700)
    return svg(W, H, b, 'A gangway between a pier and a ferry')

def hoist():
    W, H = 580, 330
    b = RECT(140, 236, 280, 74, WATER, WATER, 0)
    b += RECT(20, 220, 120, 90, '#d6d3d1', INK, 1.4) + HATCH(20, 140, 220) + RECT(420, 220, 120, 90, '#d6d3d1', INK, 1.4) + HATCH(420, 540, 220)
    b += RECT(100, 30, 360, 18, '#94a3b8', INK, 1.6, 2)
    b += RECT(104, 48, 14, 172, '#cbd5e1', INK, 1.4) + RECT(442, 48, 14, 172, '#cbd5e1', INK, 1.4)
    b += RECT(256, 48, 48, 18, '#64748b', INK, 1.2) + '<circle cx="280" cy="78" r="14" fill="#e5e7eb" stroke="%s" stroke-width="2"/>' % INK
    b += L(294, 80, 294, 152, '#334155', 2.4)
    b += RECT(170, 160, 220, 112, '#d4b483', INK, 1.8, 2) + L(170, 216, 390, 216, '#a16207', 1.2) + L(280, 160, 280, 272, '#a16207', 1.2)
    b += '<circle cx="294" cy="156" r="5" fill="none" stroke="%s" stroke-width="2"/>' % INK
    b += DIM(320, 92, 320, 150, '', BLUE) + T(328, 118, '18 m', 'start', 12, BLUE, 700) + T(328, 132, '(not to scale)', 'start', 10, MUTED)
    b += L(300, 104, 372, 104, MUTED, 1) if False else ''
    b += T(280, 22, 'hoist drum and motor on the gantry', 'middle', 12, INK, 700)
    b += L(244, 120, 294, 120, MUTED, 1) + T(240, 116, 'wire rope:', 'end', 12, INK, 700) + T(240, 130, 'mild steel, Ø 12 mm', 'end', 12, INK, 700)
    b += T(280, 196, 'lock gate', 'middle', 13, INK, 700)
    b += T(80, 300, 'canal bank', 'middle', 11, MUTED, 700) + T(480, 300, 'canal bank', 'middle', 11, MUTED, 700)
    return svg(W, H, b, 'A hoist lifting a canal lock gate on a wire rope')

def hopper():
    W, H = 600, 380
    b = HATCH(40, 440, 336, down=True)
    b += '<defs><pattern id="hm-malt" width="10" height="8" patternUnits="userSpaceOnUse"><circle cx="3" cy="3" r="1.4" fill="#a16207"/><circle cx="8" cy="6" r="1.2" fill="#ca8a04"/></pattern></defs>'
    for x in (160, 340): b += RECT(x - 3, 126, 22, 210, '#e2e8f0', '#94a3b8', 1.2)   # back legs (behind the hopper)
    b += RECT(130, 30, 240, 100, '#fef3c7', INK, 2)
    b += RECT(132, 54, 236, 76, 'url(#hm-malt)', 'none', 0)
    cone = [(130, 130), (370, 130), (282, 210), (218, 210)]
    b += '<polygon points="%s" fill="#fef3c7" stroke="%s" stroke-width="2"/>' % (' '.join('%s,%s' % p for p in cone), INK)
    b += '<polygon points="132,131 368,131 281,208 219,208" fill="url(#hm-malt)"/>'
    b += RECT(212, 210, 76, 12, '#64748b', INK, 1.4) + T(250, 240, 'outlet', 'middle', 11, MUTED, 700)
    for x in (122, 360): b += RECT(x, 126, 22, 210, '#cbd5e1', INK, 1.8)            # front legs
    b += RECT(125, 262, 16, 26, '#fef9c3', '#a16207', 1.2) + L(125, 275, 70, 300, MUTED, 1) + T(66, 304, 'strain', 'end', 11, RED, 700) + T(66, 318, 'gauges', 'end', 11, RED, 700)
    b += DIM(100, 130, 100, 336, '', BLUE) + T(94, 236, '2.5 m', 'end', 12, BLUE, 700)
    b += T(250, 22, 'malt hopper', 'middle', 13, INK, 700) + T(250, 100, 'malt', 'middle', 12, '#78350f', 700)
    b += T(250, 300, 'four legs share the load', 'middle', 12, INK, 700)
    # leg cross-section inset
    b += SQRING(510, 150, 90, 72) + T(510, 86, 'leg cross-section', 'middle', 12, INK, 700)
    b += DIM(465, 210, 555, 210, '60 mm', RED, 12, off=(0, 16))
    b += ARROW(510, 128, 510, 114, GREEN, 1.4) + ARROW(510, 92 + 6, 510, 106, GREEN, 1.4) if False else ''
    b += T(510, 154, '4.0 mm wall', 'middle', 11, GREEN, 700)
    b += T(510, 250, 'mild steel square', 'middle', 11, MUTED, 700) + T(510, 264, 'hollow section', 'middle', 11, MUTED, 700)
    return svg(W, H, b, 'A malt hopper standing on four legs made from square hollow section')

def leg_section():
    """cross-section of one hopper leg (60 mm square hollow section, 4.0 mm wall); the caption gives its title"""
    W, H = 240, 220
    b = SQRING(120, 92, 120, 104)
    b += ARROW(120, 52, 120, 31, GREEN, 1.4) + ARROW(120, 12, 120, 29, GREEN, 1.4)
    b += T(120, 88, 'wall', 'middle', 12, GREEN, 700) + T(120, 104, '4.0 mm thick', 'middle', 12, GREEN, 700)
    b += DIM(60, 170, 180, 170, '60 mm', RED, 13, off=(0, 18))
    b += T(120, 212, 'mild steel square hollow section', 'middle', 11, MUTED, 700)
    return svg(W, H, b, 'Cross-section of one leg: 60 mm square hollow section with a 4.0 mm wall')

def jib_crane():
    W, H = 600, 340
    b = RECT(300, 262, 300, 78, WATER, WATER, 0)
    b += RECT(20, 240, 280, 100, '#d6d3d1', INK, 1.6) + HATCH(20, 300, 240) + T(160, 300, 'pier', 'middle', 12, INK, 700)
    b += RECT(70, 50, 22, 190, '#94a3b8', INK, 1.8)                                    # mast
    b += RECT(80, 150, 360, 14, '#cbd5e1', INK, 1.8)                                    # jib
    b += '<circle cx="86" cy="157" r="6" fill="white" stroke="%s" stroke-width="2"/>' % INK
    b += L(84, 58, 432, 150, '#334155', 5) + '<circle cx="84" cy="58" r="5" fill="white" stroke="%s" stroke-width="2"/><circle cx="432" cy="152" r="5" fill="white" stroke="%s" stroke-width="2"/>' % (INK, INK)
    gx, gy = 258, 104
    b += '<g transform="rotate(%.1f %d %d)">%s</g>' % (math.degrees(math.atan2(92, 348)), gx, gy, foil(gx - 22, gy - 9, 44, 18, rows=4, tabs=False))
    b += L(gx, gy - 10, gx + 10, gy - 52, MUTED, 1) + T(gx + 14, gy - 56, 'strain gauges on the tie bar', 'start', 12, RED, 700)
    b += T(176, 104, 'tie bar', 'middle', 12, INK, 700)
    b += T(260, 184, 'jib', 'middle', 12, INK, 700) + T(60, 120, 'mast', 'end', 12, INK, 700)
    b += L(420, 164, 420, 214, INK, 1.6) + '<path d="M 420 214 q 0 10 -8 10" fill="none" stroke="%s" stroke-width="2"/>' % INK
    b += RECT(392, 224, 56, 30, '#fbbf24', INK, 1.4) + T(470, 244, 'load: fish boxes', 'start', 12, INK, 700)
    hull = [(380, 268), (580, 268), (560, 300), (400, 300)]
    b += '<polygon points="%s" fill="#f8fafc" stroke="%s" stroke-width="1.6"/>' % (' '.join('%s,%s' % p for p in hull), INK) + T(490, 292, 'fishing boat', 'middle', 11, MUTED, 700)
    return svg(W, H, b, 'A jib crane on a pier, with strain gauges on its tie bar')
