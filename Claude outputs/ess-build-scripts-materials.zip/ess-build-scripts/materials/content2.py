# -*- coding: utf-8 -*-
import math
from helpers import *
from content1 import area, M, SY, SYO, N2, KN2, m3, e3, sci, STEPPER, PEN, MAG, pi, SIMT, HOW
import diagrams as D
from mlib import fig, mini, row
B = ''

# ================================================================ 5
B += H1('Young&rsquo;s Modulus')
B += P('In the first, linear part of every stress&ndash;strain graph, stress is <strong>directly proportional</strong> to strain. The constant of proportionality, the gradient of that straight line, is called <strong>Young&rsquo;s modulus</strong> or the <strong>modulus of elasticity</strong>, E.')
B += FB('E = ' + fr('&sigma;', '&epsilon;'))
B += UL('Strain has no unit, so E has the same unit as stress. Values for metals are very large, so the data booklet gives them in <strong>' + KN2 + '</strong>: 1 ' + KN2 + ' = 1000 ' + N2 + '.',
        'E only applies in the <strong>elastic region</strong>, where the graph is a straight line. Never use it with a stress above the yield stress.',
        'E measures <strong>stiffness</strong>: how much a material resists being stretched or squashed. For the same stress, a material with a high E has a small strain. Mild steel (196 ' + KN2 + ') stretches only about a third as much as aluminium alloy (70 ' + KN2 + ') under the same stress, which is why an aluminium bike frame needs fatter tubes than a steel one to be equally stiff.',
        'E is a property of the material, not of the specimen: it is found in the data booklet, and a calculated value can be used to <strong>identify</strong> an unknown material.')
B += WARN('<strong>Align the units.</strong> Stress will usually be in ' + N2 + ', so multiply a data booklet value of E by 1000 before using it: mild steel E = 196 ' + KN2 + ' = 196 000 ' + N2 + '. Forgetting this gives answers that are 1000 times too big or too small.')
B += H2('Finding E from a graph')
B += P('Choose any point on the linear part of the graph that sits exactly on a grid intersection, read its stress and strain, and divide. Never use a point on the curved part of the graph, and read values carefully: the strain axis is often in ' + m3 + '.')
B += WEL('Worked example 4 &mdash; Young&rsquo;s modulus from a graph', [
    ('Read a point on the linear part of the graph', ['&sigma; = 200 ' + N2 + ', &nbsp; &epsilon; = 2.0 ' + m3 + ' = 0.0020'], None),
    ('Calculate', ['E = ' + fr('&sigma;', '&epsilon;') + ' = ' + fr('200', '0.0020'), 'E = 100 000 ' + N2 + ' = ' + F('100 ' + KN2)], None),
], top=D.worked_e(), intro='Calculate Young&rsquo;s modulus for the material whose graph is shown.')
B += SIMT('Demonstration 4 &mdash; finding Young&rsquo;s modulus', 'material=titanium_alloy', HOW + '<p style="margin:0;"><strong>Try this:</strong> test titanium alloy. Hover over a point on the <strong>linear part</strong> of the graph and note its stress and strain (the reading gives the true strain, even though the graph stretches the elastic region out). Calculate E = &sigma; &divide; &epsilon;, then check your answer against the Material analysis panel and the data booklet. For a challenge, test the <strong>Mystery Material</strong> and identify it from its Young&rsquo;s modulus and ultimate tensile stress.</p>')
d4 = 8.0; F4 = 2000; l4 = 1500; x4 = 0.85; A4 = area(d4); s4 = F4 / A4; e4 = x4 / l4; E4 = s4 / e4
B += WEL('Worked example 5 &mdash; identifying a material', [
    ('Stress', ['A = ' + fr('&pi; &times; 8.0<sup>2</sup>', '4') + ' = ' + tr(A4) + ' mm<sup>2</sup>', '&sigma; = ' + fr('2000', tr(A4)) + ' = ' + tr(s4) + ' ' + N2], None),
    ('Strain', ['&epsilon; = ' + fr('0.85', '1500') + ' = ' + tr(e4 * 1e4, 3) + ' &times; 10<sup>&minus;4</sup>'], None),
    ('Young&rsquo;s modulus', ['E = ' + fr('&sigma;', '&epsilon;') + ' = ' + fr(tr(s4), tr(e4 * 1e4, 3) + ' &times; 10<sup>&minus;4</sup>') + ' = ' + sf(E4, 3) + ' ' + N2, 'E = ' + F(sf(E4 / 1000) + ' ' + KN2)], None),
    ('Identify', ['The data booklet gives 70 ' + KN2 + ' for <strong>aluminium alloy</strong>.'], None),
], intro='A tie rod of diameter 8.0 mm and length 1.5 m stretches by 0.85 mm, within its elastic range, under a tensile load of 2.0 kN. Calculate Young&rsquo;s modulus and identify the material.')
d5, F5, l5 = 12, 15000, 3200; A5 = area(d5); s5 = F5 / A5; e5 = s5 / 196000; x5 = e5 * l5
B += P('Most Higher questions chain the formulae together. A common pattern is to find the <strong>change in length</strong> of a member: force and area give stress, the data booklet gives E, E gives strain, and strain gives change in length. Use <strong>Next</strong> to step through it.')
B += STEPPER('Worked example 6 &mdash; how far does the tie stretch?', '<p class="notes-p" style="text-align:left;margin:0 0 8px;">A mild steel tie rod in a roof truss is 3.2 m long with a diameter of 12 mm. It carries a tensile force of 15 kN. Calculate its change in length.</p>', [
    'Plan: &Delta;l = &epsilon;l, and &epsilon; = &sigma; &divide; E, and &sigma; = F &divide; A. So find A, then &sigma;, then &epsilon;, then &Delta;l.',
    'Area: A = &pi; &times; 12<sup>2</sup> &divide; 4 = ' + tr(A5) + ' mm<sup>2</sup>',
    'Stress: &sigma; = F &divide; A = 15 000 &divide; ' + tr(A5) + ' = ' + tr(s5) + ' ' + N2 + ' (well below the yield stress of 220 ' + N2 + ', so the rod is elastic and E applies)',
    'Young&rsquo;s modulus from the data booklet: mild steel E = 196 ' + KN2 + ' = 196 000 ' + N2,
    'Strain: &epsilon; = &sigma; &divide; E = ' + tr(s5) + ' &divide; 196 000 = ' + tr(e5 * 1e4, 3) + ' &times; 10<sup>&minus;4</sup>',
    'Change in length: &Delta;l = &epsilon;l = ' + tr(e5 * 1e4, 3) + ' &times; 10<sup>&minus;4</sup> &times; 3200 = ' + tr(x5, 3) + ' mm &rarr; <strong>&Delta;l = ' + sf(x5) + ' mm</strong>',
])
Ab, lb, xb = 600, 2400, 0.40; eb = xb / lb; sb = 70000 * eb; Fb = sb * Ab
xc = 3.0; ec = xc / 6000; sc = 196000 * ec; Ac = 1500 / sc; dc = math.sqrt(4 * Ac / pi)
ed = 30 / 6000; sd = 900 * ed; Ad = 750 / sd; dd = math.sqrt(4 * Ad / pi)
T5 = [
 dict(key='hmat-t5a', q='a) The stress&ndash;strain graph below shows the result of a tensile test on a material specimen. Calculate Young&rsquo;s modulus for the material, and use the data booklet to identify it.' + M(2), extra=mini(D.task_e(), 'Task 5(a)', 500),
      a=C('Read a grid point on the linear part of the graph: &sigma; = 275 ' + N2 + ', &epsilon; = 2.5 ' + m3, 'E = 275 &divide; 0.0025 = 110 000 ' + N2) + F('E = 110 ' + KN2 + ': titanium alloy'), sym=SY),
 dict(key='hmat-t5b', q='b) An aluminium alloy strut is 2.4 m long and has a cross-sectional area of 600 mm<sup>2</sup>. Under load it shortens by 0.40 mm. Calculate the compressive force in the strut.' + M(4),
      a=C('&epsilon; = 0.40 &divide; 2400 = ' + tr(eb * 1e4, 3) + ' &times; 10<sup>&minus;4</sup>', 'E = 70 ' + KN2 + ' = 70 000 ' + N2 + ' (data booklet)', '&sigma; = E&epsilon; = 70 000 &times; ' + tr(eb * 1e4, 3) + ' &times; 10<sup>&minus;4</sup> = ' + tr(sb) + ' ' + N2, 'F = &sigma;A = ' + tr(sb) + ' &times; 600 = ' + sf(Fb, 3) + ' N') + F('F = ' + sf(Fb / 1000) + ' kN'), sym=SY),
 dict(key='hmat-t5c', q='c) A vertical mild steel wire 6.0 m long stretches by 3.0 mm when a load of 1.5 kN hangs from it. Calculate the diameter of the wire.' + M(4),
      a=C('&epsilon; = 3.0 &divide; 6000 = 5.0 &times; 10<sup>&minus;4</sup>', '&sigma; = E&epsilon; = 196 000 &times; 5.0 &times; 10<sup>&minus;4</sup> = ' + sf(sc, 3) + ' ' + N2, 'A = F &divide; &sigma; = 1500 &divide; 98 = ' + tr(Ac) + ' mm<sup>2</sup>', 'd = &radic;(4A &divide; &pi;) = ' + tr(dc) + ' mm') + F('d = ' + sf(dc) + ' mm'), sym=SY),
 dict(key='hmat-t5d', q='d) A polypropylene mooring rope 6.0 m long holds a small boat with a force of 750 N. The rope must not stretch by more than 30 mm. Calculate the smallest diameter of rope that can be used.' + M(4),
      a=C('&epsilon; = 30 &divide; 6000 = 0.0050', 'E = 0.9 ' + KN2 + ' = 900 ' + N2 + ' (data booklet)', '&sigma; = E&epsilon; = 900 &times; 0.0050 = ' + sf(sd) + ' ' + N2, 'A = 750 &divide; 4.5 = ' + tr(Ad) + ' mm<sup>2</sup>', 'd = &radic;(4A &divide; &pi;) = ' + tr(dd) + ' mm') + F('d = ' + sf(dd) + ' mm'), sym=SY),
 dict(key='hmat-t5e', q='e) A mountain-bike frame can be made from mild steel or aluminium alloy tubes. Use Young&rsquo;s modulus to explain why the aluminium tubes are made with a larger diameter.' + M(2),
      a='<p>Aluminium alloy has a much lower Young&rsquo;s modulus (70 ' + KN2 + ') than mild steel (196 ' + KN2 + '), so it is less stiff: at the same stress it would strain almost three times as much and the frame would flex. A larger diameter tube gives more cross-sectional area (and resists bending better), which reduces the stress and strain so the frame is stiff enough &mdash; while aluminium&rsquo;s low density keeps it light.</p>', minh=80),
]
B += ASSIGN('task5', PEN, 'Task 5 &mdash; Young&rsquo;s modulus', T5, intro='Use the properties of materials table in the data booklet where you need it.')

# ================================================================ 6
B += H1('Elastic Strain Energy')
B += P('Work has to be done to stretch a material. In the elastic region that work is stored in the material as <strong>elastic strain energy</strong>, E<sub>s</sub>, and it is given back when the load is removed &mdash; the energy in a drawn bow, a stretched bungee cord or a wound spring. On a force&ndash;extension graph, the <strong>triangular area under the graph</strong> indicates the amount of energy stored.')
B += fig(D.strain_energy(), 'Elastic strain energy is the area of the triangle under the elastic line', 520)
B += FB('E<sub>s</sub> = &frac12;Fx')
B += P('F is the force and x is the extension in the direction of the force.')
B += UL('With F in <strong>newtons</strong> and x in <strong>metres</strong>, E<sub>s</sub> is in <strong>joules</strong>. Extensions are usually given in mm, so divide by 1000 first.',
        'The formula is only valid in the <strong>elastic region</strong>, where the graph is a straight line from the origin. Beyond the yield point the area under the graph is not a triangle, and the energy used to deform the material plastically is <strong>not</strong> given back.',
        'Strain energy links the materials topic to energy and efficiency: it is just another energy store, like E<sub>p</sub> or E<sub>k</sub>.')
B += WEL('Worked example 7 &mdash; strain energy in a rope', [
    ('Convert the extension to metres', ['x = 18 mm = 0.018 m'], None),
    ('Strain energy', ['E<sub>s</sub> = &frac12;Fx = &frac12; &times; 400 &times; 0.018', 'E<sub>s</sub> = ' + F(sf(0.5 * 400 * 0.018) + ' J')], None),
], intro='A climbing rope behaves elastically and stretches by 18 mm under a tensile force of 400 N. Calculate the strain energy stored in it.')
xs = 2 * 0.9 / 12000
B += WEL('Worked example 8 &mdash; working backwards', [
    ('Rearrange', ['E<sub>s</sub> = &frac12;Fx &rarr; x = ' + fr('2E<sub>s</sub>', 'F')], None),
    ('Substitute', ['x = ' + fr('2 &times; 0.90', '12 000') + ' = ' + sf(xs) + ' m', 'x = ' + F(sf(xs * 1000) + ' mm')], None),
], intro='A steel cable stores 0.90 J of strain energy when it carries a tensile force of 12 kN. Calculate the extension of the cable.')
Fc = 2 * 2.5 / 0.0005
T6 = [
 dict(key='hmat-t6a', q='a) Use the graph to calculate the strain energy stored in the specimen when the load is 24 kN.' + M(2),
      a=C('From the graph, at 24 kN the extension is 0.80 mm = 0.00080 m', 'E<sub>s</sub> = &frac12; &times; 24 000 &times; 0.00080 = 9.6 J') + F('E<sub>s</sub> = 9.6 J'), sym=SY),
 dict(key='hmat-t6b', q='b) Explain why E<sub>s</sub> = &frac12;Fx cannot be used to find the energy in this specimen at a load of 40 kN.' + M(1),
      a='<p>40 kN is beyond the yield point, in the plastic region, where the graph is no longer a straight line, so the area under it is not a triangle. Also, the energy used in plastic deformation is not stored: it is not returned when the load is removed.</p>'),
 dict(key='hmat-t6c', q='c) A spring stretches elastically by 40 mm under a force of 60 N. Calculate the energy stored in it.' + M(2),
      a=C('E<sub>s</sub> = &frac12; &times; 60 &times; 0.040 = 1.2 J') + F('1.2 J'), sym=SY),
 dict(key='hmat-t6d', q='d) A support cable stores 2.5 J of strain energy and changes length by 0.50 mm. Calculate the force in the cable.' + M(2),
      a=C('F = 2E<sub>s</sub> &divide; x = (2 &times; 2.5) &divide; 0.00050 = ' + sf(Fc, 3) + ' N') + F('F = 10 kN'), sym=SY),
 dict(key='hmat-t6e', q='e) A mild steel bar 2.0 m long with a cross-sectional area of 400 mm<sup>2</sup> carries a tensile load of 30 kN. Calculate the strain energy stored in the bar.' + M(4),
      a=C('&sigma; = 30 000 &divide; 400 = 75 ' + N2, '&epsilon; = 75 &divide; 196 000 = ' + tr(75 / 196000 * 1e4, 3) + ' &times; 10<sup>&minus;4</sup>', 'x = &epsilon;l = ' + tr(75 / 196000 * 1e4, 3) + ' &times; 10<sup>&minus;4</sup> &times; 2000 = ' + tr(75 / 196000 * 2000, 4) + ' mm', 'E<sub>s</sub> = &frac12; &times; 30 000 &times; ' + tr(75 / 196000 * 2, 6) + ' = ' + tr(0.5 * 30000 * 75 / 196000 * 2, 3) + ' J') + F('E<sub>s</sub> = ' + sf(0.5 * 30000 * 75 / 196000 * 2) + ' J'), sym=SY),
]
B += ASSIGN('task6', PEN, 'Task 6 &mdash; Elastic strain energy', T6, intro='<p class="notes-p" style="margin-bottom:6px;">Parts (a) and (b) use the load&ndash;extension graph from Task 1, shown again here.</p>' + mini(D.task_le(), 'The graph from Task 1', 520))

# ================================================================ 7
B += H1('Factor of Safety')
B += H2('Why structures fail')
B += P('Engineers can never be completely certain about every load a structure will meet or every flaw in its material. When a structure does fail, an investigation looks for the cause. The common causes are:')
B += TABLE(['Cause', 'What happens'], [
    ['<strong>Overloading</strong>', 'The loads are larger than the designer allowed for: misuse (too many people in a lift), a change of use since it was designed (heavier modern traffic on an old bridge), or extreme weather (snow, wind, flooding).'],
    ['<strong>Dynamic and impact loads</strong>', 'Loads that move, vary or hit suddenly (traffic, wind gusts, waves, a dropped load) cause higher stresses than the same load applied gently.'],
    ['<strong>Material faults</strong>', 'The material is not of consistent quality: hidden cracks or voids in a casting, or knots and splits in natural materials such as wood.'],
    ['<strong>Deterioration and corrosion</strong>', 'The material weakens over time. Metals <strong>corrode</strong> (iron and steel rust), wood swells, warps and rots when it gets wet, and wear reduces the cross-section.'],
    ['<strong>Joint failure</strong>', 'Poor welding, the wrong bolts, or bolts that were over- or under-tightened. Joints carry concentrated forces, so a small defect matters.'],
    ['<strong>Fatigue</strong>', 'Repeated loading and unloading, even at stresses well below the yield stress, starts tiny cracks that grow with every cycle until the member suddenly fractures. Bend a paperclip back and forth to see it happen.'],
])
B += KP('<strong>Corrosion, not just rust.</strong> Rust is the corrosion of metals that contain <strong>iron</strong>, such as steel. Other metals corrode too: aluminium, for example, can be badly pitted by seawater. So unless a question is clearly about iron or steel, write &ldquo;corrosion&rdquo; rather than &ldquo;rust&rdquo;.')
B += H2('What a factor of safety is')
B += P('To allow for all of this, a structure is designed so that it could carry several times the load it will normally carry. The ratio of the load (or stress) that would cause failure to the load (or stress) the member is designed to carry is the <strong>factor of safety</strong> (FoS).')
B += FB('Factor of safety = ' + fr('ultimate load', 'safe working load') + ' = ' + fr('ultimate stress', 'safe working stress'), 'formula-long')
B += UL('The <strong>safe working load</strong> (SWL) is the greatest load the member or product is designed to carry in normal use. Lifting equipment, cranes and lifts are marked with their SWL.',
        'The <strong>safe working stress</strong> is the stress produced by the safe working load. It must always be well below the <strong>yield stress</strong>, so the member stays in its elastic region and is never permanently deformed.',
        'For the <strong>ultimate stress</strong>, use the data booklet: the <strong>ultimate tensile stress</strong> for a member in <strong>tension</strong>, and the <strong>ultimate compressive stress</strong> for a member in <strong>compression</strong> (a strut, a column, a piston rod pushing a load).',
        'A factor of safety has no unit.')
B += fig(D.fos_scale(), 'A mild steel tie designed with a factor of safety of 5', 560)
B += P('A bar like this is a useful way to picture the different stresses in a member. Zero is at the bottom and the ultimate stress is at the top. The member is designed so that, in normal use, its stress never rises above the safe working stress, which keeps it well inside the elastic region, below the yield stress. Everything between the safe working stress and the ultimate stress is the margin left to cover the things the designer cannot predict. You will see the same kind of bar again for bolts later in this section.')
B += H2('Strength in tension and in compression')
B += P('Because the ultimate stress depends on whether a member is pulled or squashed, the data booklet gives each material an <strong>ultimate tensile stress</strong> and an <strong>ultimate compressive stress</strong>, and they are not always the same. Look at three examples:')
B += UL('<strong>Mild steel</strong>: 430 ' + N2 + ' in both tension and compression, so it can be used for ties and struts.',
        '<strong>Cast iron</strong>: 120&ndash;160 ' + N2 + ' in tension but 600&ndash;900 ' + N2 + ' in compression. It suits machine bases and columns that are squashed, not members that are pulled.',
        '<strong>Concrete</strong>: no tensile value is given at all, only 60 ' + N2 + ' in compression. Concrete cracks under very small tensile stresses, so beams and slabs are <strong>reinforced with steel bars</strong> placed where the tension is. The steel carries the tension and the concrete carries the compression, which is why reinforced concrete can be given a Young&rsquo;s modulus and a higher compressive stress in the table.')
B += P('Natural materials vary. Wood is much stronger along the grain than across it, and every piece is different because of knots and defects. That uncertainty is one reason engineers apply a larger factor of safety to wood.')
B += H2('Choosing the factor of safety')
B += P('There is no single correct value. The engineer chooses the factor of safety from experience, codes of practice and a risk assessment, considering:')
B += UL('the <strong>consequences of failure</strong>: the risk to people, and the cost of repairing or replacing the structure. A lift, a fairground ride or a road bridge needs a much higher factor than a garden shelf;',
        'the <strong>type of load</strong>: static loads are predictable; dynamic, impact and repeated loads (fatigue) need a higher factor;',
        'how <strong>accurately the loads are known</strong> and how thoroughly the design has been calculated and tested;',
        'the <strong>reliability of the material</strong>: manufactured metals are consistent; natural materials such as wood vary;',
        'the <strong>environment</strong>: exposure to weather, seawater or chemicals causes corrosion and wear over the life of the structure;',
        'the quality of <strong>manufacture and construction</strong>, and of maintenance and inspection.')
B += P('A higher factor of safety is not automatically better. It means larger or stronger members, so more material, more <strong>cost</strong>, more <strong>weight</strong> (which itself adds load) and a bigger <strong>environmental impact</strong>. Aircraft use low factors of safety, around 1.5, because every kilogram matters &mdash; and they make up for it with very accurate calculation, extensive testing and frequent inspection. Lifting equipment that carries people may use 10 or more.')
B += KP('<strong>Exam tip: &ldquo;Explain the appropriateness of the factor of safety.&rdquo;</strong> Say whether it is high or low, then link it to the situation: the risk to life, the cost, the weight, the type of loading or the environment. For example: &ldquo;A high factor of safety is appropriate because failure of the lift would put passengers&rsquo; lives at risk.&rdquo;')
B += H2('Calculating factor of safety')
dA = 20; FA = 9000; AA = area(dA); sA = FA / AA
B += WEL('Worked example 9 &mdash; factor of safety of a tie', [
    ('Area and stress', ['A = ' + fr('&pi; &times; 20<sup>2</sup>', '4') + ' = ' + tr(AA) + ' mm<sup>2</sup>', '&sigma; = ' + fr('9000', tr(AA)) + ' = ' + tr(sA) + ' ' + N2], None),
    ('Ultimate tensile stress (data booklet)', ['aluminium alloy: UTS = 300 ' + N2], None),
    ('Factor of safety', ['FoS = ' + fr('ultimate stress', 'safe working stress') + ' = ' + fr('300', tr(sA)), 'FoS = ' + F(sf(300 / sA))], None),
    ('Check, using loads instead', ['ultimate load = UTS &times; A = 300 &times; ' + tr(AA) + ' = ' + sf(300 * AA, 3) + ' N', 'FoS = ' + fr(sf(300 * AA, 3), '9000') + ' = ' + sf(300 * AA / 9000) + ' (the same)'], None),
], intro='An aluminium alloy tie of diameter 20 mm carries a safe working load of 9.0 kN in tension. Calculate the factor of safety.')
Fp, fos = 30000, 8; sw = 430 / fos; Ap = Fp / sw; dp = math.sqrt(4 * Ap / pi)
B += STEPPER('Worked example 10 &mdash; designing a piston rod', '<p class="notes-p" style="text-align:left;margin:0 0 8px;">The mild steel piston rod of a pneumatic cylinder pushes a load with a force of 30 kN. A factor of safety of 8 is required. Calculate the minimum diameter of the rod.</p>', [
    'The rod <strong>pushes</strong>, so it is in <strong>compression</strong>: use the ultimate <strong>compressive</strong> stress. Mild steel: 430 ' + N2 + '.',
    'Safe working stress = ultimate stress &divide; FoS = 430 &divide; 8 = ' + sf(sw, 4) + ' ' + N2,
    'Area needed: A = F &divide; &sigma; = 30 000 &divide; ' + sf(sw, 4) + ' = ' + tr(Ap) + ' mm<sup>2</sup>',
    'Diameter: d = &radic;(4A &divide; &pi;) = &radic;(4 &times; ' + tr(Ap) + ' &divide; &pi;) = ' + tr(dp) + ' mm &rarr; <strong>d = ' + sf(dp) + ' mm</strong>',
    'In practice the designer would choose the next standard size <strong>up</strong> (e.g. 28 or 30 mm). Rounding a diameter down would make the stress higher and the factor of safety lower than required.',
])
B += H2('Bolts that are already tightened')
B += P('When a nut is tightened, it stretches the bolt, so the bolt already carries a tensile stress before any load is applied. The factor of safety sets the <strong>total</strong> stress the bolt may carry (the safe working stress). Part of that is already used up by the tightening, so the load can only add the <strong>remaining</strong> stress.')
B += fig(D.bolts(), 'The safe working stress in a bolt is shared between the tightening and the load<br>(the numbers are from Worked example 11)', 660)
B += KP('<strong>Remember the order:</strong> safe working stress = ultimate stress &divide; FoS, <em>then</em> subtract the tightening stress, <em>then</em> use the stress that is left with the load to find the area.')
ub, fb, t0, Fb1 = 430, 4.0, 8.0, 6000; swb = ub / fb; avb = swb - t0; Abb = Fb1 / avb; dbb = math.sqrt(4 * Abb / pi)
B += WEL('Worked example 11 &mdash; pre-tightened bolts', [
    ('Total safe working stress', ['&sigma;<sub>sw</sub> = ' + fr('430', '4.0') + ' = ' + sf(swb, 4) + ' ' + N2], None),
    ('Stress left for the load', ['107.5 &minus; 8.0 = ' + sf(avb, 3) + ' ' + N2], None),
    ('Area and diameter', ['A = ' + fr('6000', sf(avb, 3)) + ' = ' + tr(Abb) + ' mm<sup>2</sup>', 'd = ' + SQ(fr('4 &times; ' + tr(Abb), '&pi;')) + ' = ' + tr(dbb) + ' mm', 'd = ' + F(sf(dbb) + ' mm')], None),
], intro='A bracket is held by mild steel bolts. Each bolt is tightened to a stress of 8.0 ' + N2 + ', and then carries a tensile load of 6.0 kN. A factor of safety of 4.0 is required. Calculate the diameter of each bolt.')
Fr = 60000; Ar = area(40); sr = Fr / Ar
dS = 30000 / (300 / 6); dS2 = math.sqrt(4 * dS / pi)
st = 110000 * 0.03 / 120
Fv = 0.80 * area(120); swv = 430 / 5 - 6; Fper = swv * area(10)
T7 = [
 dict(key='hmat-t7a', q='a) Describe <strong>three</strong> different causes of structural failure.' + M(3),
      a='<p>Any three, described: overloading (loads greater than designed for, e.g. misuse, change of use or extreme weather); dynamic or impact loads; material faults (inconsistent quality, hidden flaws, knots in wood); deterioration and corrosion reducing the cross-section; joint failure (poor welds, wrong or loose bolts); fatigue (repeated loading cycles cause cracks that grow until the member fractures).</p>', minh=90),
 dict(key='hmat-t7b', q='b) A lighting rig in a theatre hangs above the audience on steel wire ropes. A factor of safety of 10 is used. Explain why such a high factor of safety is appropriate.' + M(2),
      a='<p>The rig hangs directly above people, so failure could cause serious injury or death: the risk to life is very high. The load also changes (lights are added, moved and adjusted, and the rig is raised and lowered), so it is dynamic and repeated, which could cause fatigue.</p>'),
 dict(key='hmat-t1c', q='c) Use the data booklet to explain why cast iron is suitable for the base of a large machine tool but not for a tie in a roof truss.' + M(2),
      a='<p>The base of a machine is squashed by the weight of the machine, so it is in <strong>compression</strong>, and cast iron has a high ultimate compressive stress (600&ndash;900 ' + N2 + '). A tie is in <strong>tension</strong>, and cast iron has a much lower ultimate tensile stress (120&ndash;160 ' + N2 + '). It is also brittle, so a tie could snap suddenly without warning.</p>', minh=70),
 dict(key='hmat-t1d', q='d) Explain why steel bars are placed in the bottom of a concrete beam that carries a load across a gap.' + M(2),
      a='<p>When the beam bends under the load, its bottom is stretched (in tension) and its top is squashed (in compression). Concrete is strong in compression but very weak in tension (the data booklet gives it no tensile strength), so the bottom would crack. Steel is strong in tension, so the bars carry the tensile forces while the concrete carries the compression.</p>', minh=70),
 dict(key='hmat-t7c', q='e) A mild steel wire rope of diameter 40 mm lifts a load of 60 kN at a steady speed. Calculate the factor of safety.' + M(4),
      a=C('A = &pi; &times; 40<sup>2</sup> &divide; 4 = ' + tr(Ar) + ' mm<sup>2</sup>', '&sigma; = 60 000 &divide; ' + tr(Ar) + ' = ' + tr(sr) + ' ' + N2, 'UTS (mild steel) = 430 ' + N2, 'FoS = 430 &divide; ' + tr(sr) + ' = ' + tr(430 / sr)) + F('FoS = ' + sf(430 / sr)), sym=SY),
 dict(key='hmat-t7d', q='f) An aluminium alloy strut must carry a compressive force of 30 kN with a factor of safety of 6. Calculate the minimum diameter of the strut.' + M(4),
      a=C('Compression, so use the ultimate compressive stress: 300 ' + N2, '&sigma;<sub>sw</sub> = 300 &divide; 6 = 50 ' + N2, 'A = 30 000 &divide; 50 = 600 mm<sup>2</sup>', 'd = &radic;(4 &times; 600 &divide; &pi;) = ' + tr(dS2) + ' mm') + F('d = ' + sf(dS2) + ' mm'), sym=SY),
 dict(key='hmat-t7e', q='g) A titanium alloy bar 120 mm long stretches elastically by 0.030 mm under its working load. Calculate the factor of safety.' + M(4),
      a=C('&epsilon; = 0.030 &divide; 120 = 2.5 &times; 10<sup>&minus;4</sup>', 'E = 110 ' + KN2 + ' = 110 000 ' + N2, '&sigma; = E&epsilon; = 110 000 &times; 2.5 &times; 10<sup>&minus;4</sup> = ' + sf(st, 3) + ' ' + N2, 'FoS = UTS &divide; &sigma; = 1000 &divide; 27.5 = ' + tr(1000 / st)) + F('FoS = ' + sf(1000 / st)), sym=SY),
 dict(key='hmat-t7f', q='h) A valve block seals the 120 mm diameter outlet of a compressed-air receiver. The air pressure is 0.80 ' + N2 + '. The block is held on by mild steel bolts of diameter 10 mm, each tightened to a stress of 6.0 ' + N2 + '. A factor of safety of 5 is required. Calculate the number of bolts needed.' + M(5),
      a=C('Force on the block: F = PA = 0.80 &times; &pi; &times; 120<sup>2</sup> &divide; 4 = ' + tr(Fv) + ' N', 'Safe working stress = 430 &divide; 5 = 86 ' + N2, 'Stress left for the load = 86 &minus; 6.0 = 80 ' + N2, 'Load each bolt can carry = 80 &times; (&pi; &times; 10<sup>2</sup> &divide; 4) = ' + tr(Fper) + ' N', 'Number = ' + tr(Fv) + ' &divide; ' + tr(Fper) + ' = ' + tr(Fv / Fper)) + F('2 bolts') + NOTE('Always round the number of bolts <strong>up</strong>: 1 bolt would be overstressed. (In practice an even number spaced around the block, such as 4, would be used to spread the load.)'), sym=SY),
 dict(key='hmat-t7g', q='i) A member in a warehouse racking frame was designed with a factor of safety of 15. A structural engineer advised that 2.5 would be enough. State <strong>two</strong> reasons for this advice.' + M(2),
      a='<p>Any two: the risk to life from failure is low; a factor of 15 wastes material and increases cost; it adds unnecessary weight; the loads are static and well known, so are unlikely to exceed the design load; indoors the member is unlikely to suffer corrosion or weathering.</p>'),
]
B += ASSIGN('task7', PEN, 'Task 7 &mdash; Factor of safety', T7, intro='Use the properties of materials table in the data booklet. Decide first whether each member is in tension or compression.')

# ================================================================ 8
B += H1('Strain Gauges')
B += P('Tensile tests are done on specimens in a laboratory. To measure the strain in a real member while it is working &mdash; a bridge cable, an aircraft wing, the arm of a crane &mdash; engineers bond a <strong>strain gauge</strong> to its surface.')
B += fig(D.gauge(), 'A foil strain gauge: the long runs of foil lie along the direction it measures', 600)
B += UL('A strain gauge is a very thin metal foil track, folded back and forth in a zig-zag, on a flexible plastic backing. It is glued firmly to the member with its <strong>long runs lined up with the direction of the strain</strong> to be measured, so it stretches and squashes exactly as the surface does. Lining up the long runs means as much of the track as possible is stretched, which gives the biggest change in resistance.',
        'In <strong>tension</strong> the foil tracks become longer and thinner, so the gauge&rsquo;s <strong>resistance increases</strong>. In <strong>compression</strong> they become shorter and fatter, so its <strong>resistance decreases</strong>.',
        'The change is tiny: a typical gauge of 120 &Omega; may change by less than 1 &Omega;. The signal must therefore be <strong>amplified</strong>, usually with a difference amplifier.',
        'From the strain, engineers can find the stress (&sigma; = E&epsilon;) and so the load (F = &sigma;A). This is how <strong>load cells</strong> in weighing scales, crane overload alarms and bridge-monitoring systems work.')
B += H2('Active and passive gauges')
B += P('The resistance of the foil also changes with <strong>temperature</strong>, and the member itself expands and contracts as it warms and cools. On its own, a single gauge cannot tell the difference between strain caused by the load and a change caused by temperature.')
B += P('The solution is a second, identical gauge. The <strong>active</strong> gauge is bonded where the load strains the member. The <strong>passive</strong> (or dummy) gauge is mounted close by, on the same material at the same temperature, but where it is <strong>not strained</strong> by the load &mdash; for example on an unloaded piece of the same material, or at right angles to the strain. The diagram shows both positions.')
B += fig(D.gauge_positions(), 'Where to put the active and passive gauges', 660)
B += P('Each gauge goes in its own voltage divider. A temperature change affects both gauges equally, so the two divider voltages change together and their <strong>difference</strong> does not change. Only the strain from the load changes the difference. The passive gauge acts as a <strong>reference</strong> for the active gauge.')
B += fig(D.gauge_circuit(), 'Active and passive strain gauges feeding a difference amplifier', 640)
B += P('The difference amplifier amplifies only the difference between its inputs: V<sub>out</sub> = ' + fr('R<sub>f</sub>', 'R<sub>i</sub>') + '(V<sub>2</sub> &minus; V<sub>1</sub>). You met this circuit in the <a href="../../electronics/analogue/course-notes.html" style="color:var(--teal-800);">Higher Analogue Electronics notes</a>. A comparator can be used instead where an on/off signal is needed, such as an overload alarm.')
V1 = 5 * 120 / 1120; V2 = 5 * 121.2 / 1121.2; Vo = 330 * (V2 - V1)
B += WEL('Worked example 12 &mdash; a strain gauge amplifier', [
    ('Divider voltages', ['V<sub>1</sub> = 5.0 &times; ' + fr('120', '1000 + 120') + ' = ' + tr(V1, 4) + ' V', 'V<sub>2</sub> = 5.0 &times; ' + fr('121.2', '1000 + 121.2') + ' = ' + tr(V2, 4) + ' V'], None),
    ('Output', ['V<sub>out</sub> = ' + fr('R<sub>f</sub>', 'R<sub>i</sub>') + '(V<sub>2</sub> &minus; V<sub>1</sub>) = ' + fr('330', '1.0') + ' &times; (' + tr(V2, 5) + ' &minus; ' + tr(V1, 5) + ')', 'V<sub>out</sub> = ' + F(sf(Vo) + ' V')], None),
], intro='In the circuit above, both gauges are 120 &Omega; when unstrained, R<sub>f</sub> = 330 k&Omega; and R<sub>i</sub> = 1.0 k&Omega;. Under load, the active gauge rises to 121.2 &Omega;. Calculate V<sub>out</sub>. (Notice the difference between V<sub>2</sub> and V<sub>1</sub> is less than 5 mV: that is why it must be amplified.)')
At8 = pi * (48 ** 2 - 40 ** 2) / 4; s8 = 196000 * 1.5e-4; F8 = s8 * At8
V2b = 5 * 120.6 / 1120.6; Vob = 330 * (V2b - V1)
T8 = [
 dict(key='hmat-t8a', q='a) Explain why the resistance of a strain gauge changes when the member it is bonded to is (i) in tension and (ii) in compression.' + M(2),
      a='<p>The resistance of a conductor increases with its length and decreases as its cross-sectional area increases. (i) In tension the foil tracks are stretched <strong>longer and thinner</strong>, so the resistance <strong>increases</strong>. (ii) In compression they become <strong>shorter and thicker</strong>, so the resistance <strong>decreases</strong>.</p>'),
 dict(key='hmat-t8b', q='b) Describe the purpose of the passive strain gauge.' + M(1),
      a='<p>It compensates for temperature: it is affected by temperature changes in the same way as the active gauge but is not strained, so it acts as a reference and the effect of temperature cancels out, leaving only the strain caused by the load.</p>'),
 dict(key='hmat-t8c', q='c) State where the passive gauge should be mounted.' + M(1),
      a='<p>Close to the active gauge, on the same material and at the same temperature, but where it is not strained by the load (e.g. on an unloaded piece of the same material, or at 90&deg; to the direction of strain).</p>'),
 dict(key='hmat-t8d', q='d) In the circuit in Worked example 12, a smaller load makes the active gauge 120.6 &Omega;. Calculate V<sub>out</sub>.' + M(3),
      a=C('V<sub>1</sub> = 5.0 &times; 120 &divide; 1120 = ' + tr(V1, 5) + ' V', 'V<sub>2</sub> = 5.0 &times; 120.6 &divide; 1120.6 = ' + tr(V2b, 5) + ' V', 'V<sub>out</sub> = 330 &times; (' + tr(V2b, 5) + ' &minus; ' + tr(V1, 5) + ') = ' + tr(Vob, 3) + ' V') + F('V<sub>out</sub> = ' + sf(Vob) + ' V'), sym=SYO),
 dict(key='hmat-t8e', q='e) A strain gauge on a mild steel tube shows a strain of 1.5 &times; 10<sup>&minus;4</sup>. The tube has an outside diameter of 48 mm and an inside diameter of 40 mm. Calculate the load carried by the tube.' + M(4),
      a=C('A = &pi;(48<sup>2</sup> &minus; 40<sup>2</sup>) &divide; 4 = ' + tr(At8) + ' mm<sup>2</sup>', 'E = 196 000 ' + N2, '&sigma; = E&epsilon; = 196 000 &times; 1.5 &times; 10<sup>&minus;4</sup> = ' + sf(s8, 3) + ' ' + N2, 'F = &sigma;A = ' + sf(s8, 3) + ' &times; ' + tr(At8) + ' = ' + sf(F8, 4) + ' N') + F('F = ' + sf(F8 / 1000) + ' kN'), sym=SYO),
]
B += ASSIGN('task8', PEN, 'Task 8 &mdash; Strain gauges', T8)
