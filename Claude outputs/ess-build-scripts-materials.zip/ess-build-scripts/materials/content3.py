# -*- coding: utf-8 -*-
import math
from helpers import *
from content1 import area, M, SY, N2, KN2, m3, PEN, MAG, pi
import diagrams as D
from mlib import fig, mini, row, img
B = ''

# ================================================================ 9
B += H1('Exam-Style Questions')
B += P('These questions are set out like Higher exam questions, with the marks shown. Show all your working, use the data booklet, and give final answers to 2 significant figures with units.')
# Q1
B += H2('Question 1 &mdash; Testing a material for a marina gangway')
B += P('A sample of a material proposed for a new gangway at a marina in Oban was tested in a laboratory. The stress&ndash;strain graph is shown.')
B += img('q1-marina-gangway.jpg', 'A metal gangway with handrails leading down from the shore to the floating pontoons of a marina, with yachts and motor boats moored alongside', 'A marina gangway: it links the shore to the floating pontoons', 408)
Q1 = [
 dict(key='hmat-e1a', q='(a) State the yield stress of the material.' + M(1), a=F('250 ' + N2)),
 dict(key='hmat-e1b', q='(b) Calculate Young&rsquo;s modulus for the material.' + M(1),
      a=C('Point on the straight line: &sigma; = 140 ' + N2 + ', &epsilon; = 2.0 ' + m3, 'E = 140 &divide; 0.0020 = 70 000 ' + N2) + F('E = 70 ' + KN2), sym=SY),
 dict(key='hmat-e1c', q='(c) Use the data booklet to identify the material. Justify your answer.' + M(1),
      a='<p><strong>Aluminium alloy</strong>: its Young&rsquo;s modulus (70 ' + KN2 + '), yield stress (250 ' + N2 + ') and UTS (300 ' + N2 + ') all match the data booklet.</p>'),
 dict(key='hmat-e1d', q='(d) Describe the effect on the material of applying and then removing a load that produces a stress of 150 ' + N2 + '.' + M(1),
      a='<p>The material stretches, then returns to its original length when the load is removed, because 150 ' + N2 + ' is in the elastic region (below the yield stress).</p>'),
 dict(key='hmat-e1e', q='(e) A second material is stiffer. Describe how its stress&ndash;strain graph would differ in the elastic region.' + M(1),
      a='<p>A straight line from the origin with a <strong>steeper gradient</strong> (a higher Young&rsquo;s modulus).</p>'),
]
B += ASSIGN('exam1', MAG, 'Question 1 &mdash; Gangway material', Q1, intro=mini(D.exam_ss(), 'Question 1: stress&ndash;strain graph', 520))
# Q2
A2 = area(12); s2 = 7500 / A2; fos2 = 430 / s2; e2 = s2 / 196000; x2 = e2 * 18000; Es2 = 0.5 * 7500 * x2 / 1000
B += H2('Question 2 &mdash; Lifting a canal lock gate')
B += P('During maintenance on the Caledonian Canal, lock gates are lifted out by mobile cranes. Each crane hook is held up by several lengths of mild steel wire rope, each with a diameter of 12 mm, and the gate is lifted at a steady speed. The engineer who planned the lift identified the maximum tension in each length of rope as 7.5 kN. Each length of rope between the top of the crane jib and the hook is 18 m long.')
B += img('q2-lock-gate-cranes.jpg', 'Two yellow mobile cranes beside a canal lock, their long jibs lowering wire ropes and hooks to lift a lock gate, with workers in high-visibility clothing and snow-capped mountains behind', 'Mobile cranes lifting a lock gate on the Caledonian Canal', 408)
Q2 = [
 dict(key='hmat-e2a', q='(a) Calculate the factor of safety of one length of rope when the tension is 7.5 kN.' + M(4),
      a=C('A = &pi; &times; 12<sup>2</sup> &divide; 4 = ' + tr(A2) + ' mm<sup>2</sup>', '&sigma; = 7500 &divide; ' + tr(A2) + ' = ' + tr(s2) + ' ' + N2, 'UTS (mild steel) = 430 ' + N2, 'FoS = 430 &divide; ' + tr(s2) + ' = ' + tr(fos2)) + F('FoS = ' + sf(fos2)), sym=SY),
 dict(key='hmat-e2b', q='(b) Calculate the change in length of one length of rope.' + M(3),
      a=C('E = 196 000 ' + N2, '&epsilon; = &sigma; &divide; E = ' + tr(s2) + ' &divide; 196 000 = ' + tr(e2 * 1e4, 3) + ' &times; 10<sup>&minus;4</sup>', '&Delta;l = &epsilon;l = ' + tr(e2 * 1e4, 3) + ' &times; 10<sup>&minus;4</sup> &times; 18 000 = ' + tr(x2) + ' mm') + F('&Delta;l = ' + sf(x2) + ' mm'), sym=SY),
 dict(key='hmat-e2c', q='(c) Calculate the elastic strain energy stored in one length of rope.' + M(2),
      a=C('E<sub>s</sub> = &frac12;Fx = &frac12; &times; 7500 &times; ' + tr(x2 / 1000, 5) + ' = ' + tr(Es2) + ' J') + F('E<sub>s</sub> = ' + sf(Es2) + ' J'), sym=SY),
 dict(key='hmat-e2d', q='(d) Explain whether this factor of safety is appropriate for this application.' + M(1),
      a='<p>A suitable, justified answer, e.g. it is appropriate: maintenance workers may be near or below the gate, so failure would put lives at risk, and the rope works outdoors where it may corrode; a factor of about 6&ndash;7 is typical for lifting equipment. (A well-justified argument that it should be higher, because people work underneath, is also acceptable.)</p>'),
]
B += ASSIGN('exam2', MAG, 'Question 2 &mdash; Lifting a lock gate', Q2)
# Q3: a pair of hoppers, each on six legs
m3h, nlegs = 9600, 6
Fb3 = 2 * m3h * 9.8; F3 = m3h * 9.8 / nlegs; A3 = 60 ** 2 - 52 ** 2; s3 = F3 / A3; fos3 = 430 / s3; e3s = s3 / 196000; x3 = e3s * 2500
B += H2('Question 3 &mdash; Distillery malt hoppers')
B += P('A hopper is a large container that stores loose material, such as grain, and lets it out through an outlet at the bottom.')
B += P('A Speyside distillery stores malt in a <strong>pair</strong> of identical hoppers, which stand outside on a concrete base. <strong>Each</strong> hopper stands on <strong>six</strong> legs made from mild steel square hollow section, 60 mm &times; 60 mm on the outside with a wall thickness of 4.0 mm. Each leg is 2.5 m long. When full, each hopper and its malt have a total mass of 9600 kg, shared equally between that hopper&rsquo;s six legs.')
B += ('      <div class="pair-row">'
      '<figure class="circuit-figure"><img src="images/q3-hoppers.jpg" alt="A pair of tall galvanised steel hoppers with cone-shaped bottoms, each standing on steel legs on a concrete base"><figcaption>The pair of hoppers</figcaption></figure>'
      '<figure class="circuit-figure">%s<figcaption>Cross-section of one leg</figcaption></figure></div>\n') % D.leg_section()
Q3 = [
 dict(key='hmat-e3f', q='(a) Calculate the total force that the two full hoppers exert on the concrete base.' + M(1),
      a=C('F = 2 &times; 9600 &times; 9.8 = ' + sf(Fb3, 6) + ' N') + F('F = ' + sf(Fb3 / 1000) + ' kN'), sym=SY),
 dict(key='hmat-e3a', q='(b) Calculate the stress in each leg when the hoppers are full.' + M(4),
      a=C('Each hopper is shared between its own 6 legs: F = (9600 &times; 9.8) &divide; 6 = ' + sf(F3, 5) + ' N', 'inside = 60 &minus; (2 &times; 4.0) = 52 mm', 'A = 60<sup>2</sup> &minus; 52<sup>2</sup> = ' + str(A3) + ' mm<sup>2</sup>', '&sigma; = ' + sf(F3, 5) + ' &divide; ' + str(A3) + ' = ' + tr(s3) + ' ' + N2) + F('&sigma; = ' + sf(s3) + ' ' + N2)
        + NOTE('A common mistake is to share the load of <em>both</em> hoppers between six legs, or one hopper between twelve. Each hopper stands on its own six legs.'), sym=SY),
 dict(key='hmat-e3b', q='(c) Calculate the factor of safety of each leg.' + M(2),
      a=C('The legs are in compression: ultimate compressive stress (mild steel) = 430 ' + N2, 'FoS = 430 &divide; ' + tr(s3) + ' = ' + tr(fos3)) + F('FoS = ' + sf(fos3)), sym=SY),
 dict(key='hmat-e3c', q='(d) Calculate how much each leg shortens when its hopper is filled.' + M(3),
      a=C('&epsilon; = ' + tr(s3) + ' &divide; 196 000 = ' + tr(e3s * 1e5, 3) + ' &times; 10<sup>&minus;5</sup>', '&Delta;l = &epsilon;l = ' + tr(e3s * 1e5, 3) + ' &times; 10<sup>&minus;5</sup> &times; 2500 = ' + tr(x3, 3) + ' mm') + F('&Delta;l = ' + sf(x3) + ' mm'), sym=SY),
 dict(key='hmat-e3d', q='(e) The distillery wants to know how much malt is in each hopper. Strain gauges are bonded to one leg of each hopper. Explain why the leg&rsquo;s strain can be used to find the mass of malt in that hopper.' + M(2),
      a='<p>The leg behaves elastically, so its strain is proportional to the stress (&sigma; = E&epsilon;), and the stress is proportional to the load (F = &sigma;A). The strain therefore rises in proportion to the weight of malt in the hopper, so the gauge reading can be calibrated to give the mass.</p>'),
 dict(key='hmat-e3e', q='(f) The hoppers stand outside, where the temperature changes between day and night. Explain how the strain gauge circuit can be designed so that this does not affect the reading.' + M(2),
      a='<p>Use a second, <strong>passive</strong> gauge, identical to the active one and at the same temperature but not strained by the load, in a second voltage divider. Temperature changes affect both gauges equally, so the difference between the two divider voltages (amplified by a difference amplifier) changes only with strain.</p>'),
]
B += ASSIGN('exam3', MAG, 'Question 3 &mdash; Malt hoppers', Q3)

# ================================================================ 10
B += H1('Extension: Design Challenges')
B += KP('<strong>Extension.</strong> These challenges go beyond what the exam asks. Each one is set out like the Higher assignment: <strong>analyse</strong> the problem, <strong>design</strong> a solution with calculations, decide how you would <strong>build and test</strong> it, and <strong>evaluate</strong> it against the specification. There is no single right answer.')
B += WARN('<strong>&#x1F527; Practical tasks.</strong> Challenges marked <span class="prac-badge">&#x1F527; Practical: needs equipment</span> involve building and testing something, so they need equipment and supervision. Teachers can decide whether to run them in class, set them as a demonstration, or ask pupils to do only the design and evaluation parts. The other challenges can be done on paper.')
# DC1
Aw = 1600 / (430 / 10); dw = math.sqrt(4 * Aw / pi); A8 = area(8); s8 = 1600 / A8; x8 = s8 / 196000 * 250000
B += '      <h2 class="notes-h2" id="dc1">Challenge 1 &mdash; Highland zip wire</h2>\n'
B += P('An adventure centre near Fort William is building a 250 m zip wire across a gorge. You have been asked to specify the cable.')
B += SPEC('The greatest tension in the cable, including the effect of a rider braking at the end, is 1.6 kN.',
          'A factor of safety of at least 10 is required, because riders&rsquo; lives depend on the cable.',
          'The cable must not stretch by more than 200 mm under the greatest tension.',
          'The cable will be outdoors all year in wet weather.')
B += ASSIGN('dc1', '&#x1F3D4;&#xFE0F;', 'Challenge 1 &mdash; Zip wire cable', [
 dict(key='hmat-dc1a', q='a) <strong>Analyse.</strong> Explain why a factor of safety of at least 10 is specified, and identify the property of the material that limits the stretch of the cable.',
      a='<p>The risk to life is very high; the load is dynamic (riders bounce and brake) and repeated many times a day, so fatigue is possible; the cable is outdoors and may corrode. The stretch is limited by the stiffness of the material, its Young&rsquo;s modulus (and by the cable&rsquo;s cross-sectional area).</p>', minh=80),
 dict(key='hmat-dc1b', q='b) <strong>Design.</strong> Choose a material from the data booklet and calculate the minimum diameter of cable. Then check your chosen diameter against the stretch limit.',
      a=C('One solution, mild steel: &sigma;<sub>sw</sub> = 430 &divide; 10 = 43 ' + N2, 'A = 1600 &divide; 43 = ' + tr(Aw) + ' mm<sup>2</sup> &rarr; d = ' + tr(dw) + ' mm, so choose an 8.0 mm cable', 'Check: A = ' + tr(A8) + ' mm<sup>2</sup>, &sigma; = ' + tr(s8) + ' ' + N2, '&epsilon; = ' + tr(s8) + ' &divide; 196 000; &Delta;l = &epsilon; &times; 250 000 = ' + tr(x8) + ' mm') + F('An 8.0 mm mild steel cable: FoS = ' + sf(430 / s8) + ', stretch about ' + sf(x8) + ' mm (under 200 mm)') + NOTE('Stainless steel (UTS 760&ndash;1280 ' + N2 + ') would allow a thinner cable and would resist corrosion much better, at a higher cost. Accept any material and size that is justified and correctly calculated.'), minh=110, sym=SY),
 dict(key='hmat-dc1c', q='c) <strong>Test and evaluate.</strong> Describe how the cable could be tested before the zip wire opens, and evaluate your design against each point of the specification.',
      a='<p>E.g. proof-load the installed cable with a test load (e.g. 1.5 &times; the working load, still well inside the elastic region) using sandbags, and measure the sag and stretch; check every anchor and joint; inspect regularly for corrosion, broken strands and wear. Evaluation should comment on all four specification points, including how corrosion will be prevented (galvanised or stainless steel, lubrication, inspection).</p>', minh=90),
], intro='')
# DC2
B += '      <h2 class="notes-h2" id="dc2">Challenge 2 &mdash; Build your own tensile test <span class="prac-badge">&#x1F527; Practical: needs equipment</span></h2>\n'
B += P('<em>Equipment: a clamp stand or a sturdy beam to hang from, a mass hanger and slotted masses, a ruler or a pointer and fixed scale, scissors, safety glasses, and padding to catch the masses.</em>')
B += P('A tensometer is expensive, but the principle is simple. Design and carry out a tensile test that compares two everyday materials, such as strips cut from two different plastic bags, elastic bands, or lengths of fishing line.')
B += SPEC('Test specimens must be the same shape and size for a fair comparison.',
          'Load must be added in equal steps, and the extension measured at each step, until the specimen breaks.',
          'Results must be plotted as a load&ndash;extension graph for each material on the same axes.',
          'The test must be safe: protect eyes and feet from a specimen snapping and masses falling.')
B += ASSIGN('dc2', '&#x1F9EA;', 'Challenge 2 &mdash; Tensile test', [
 dict(key='hmat-dc2a', q='a) <strong>Design and build.</strong> Draw and describe your test rig, explaining how you will make the specimens identical and how you will measure the extension accurately.',
      a='<p>E.g. clamp the top of the specimen to a retort stand or a beam; hang a mass hanger from the bottom; mark a gauge length (e.g. 100 mm) and measure it with a ruler or a pointer against a fixed scale; cut specimens with a template so the width and length are the same; add 50 g or 100 g masses in steps; place a box of padding under the masses and wear safety glasses.</p>', minh=100),
 dict(key='hmat-dc2b', q='b) <strong>Test.</strong> Record your results in a table and plot both load&ndash;extension graphs. Mark the elastic region, the yield point and the breaking point on each.',
      a='<p>Results table with load (N, using F = mg) and extension (mm) for each material; graphs plotted on the same axes; for most plastics there is a short straight elastic region followed by a long plastic region, then fracture.</p>', minh=100),
 dict(key='hmat-dc2c', q='c) <strong>Evaluate.</strong> Compare the two materials using at least three properties (strength, stiffness, elasticity, ductility). Then describe two sources of error in your test and how they could be reduced.',
      a='<p>Comparisons should use the graphs (higher maximum load = stronger; steeper start = stiffer; longer plastic region = more ductile). Errors: reading the ruler (parallax), the specimen creeping (stretching over time) between readings, uneven cutting, slipping at the clamp, adding masses with a jolt (a dynamic load). Improvements: repeat with several specimens and average, wait a fixed time before each reading, use a pointer and fixed scale, use smaller load steps near the yield point.</p>', minh=100),
], intro='')
# DC3
Ad = 24000 / (430 / 6); dd3 = math.sqrt(4 * Ad / pi); A22 = area(22); s22 = 24000 / A22; e22 = s22 / 196000
R22 = 120 + 0.2 * e22 / 1e-4; V1 = 5 * 120 / 1120; V2 = 5 * R22 / (1000 + R22); Vo = 330 * (V2 - V1)
B += '      <h2 class="notes-h2" id="dc3">Challenge 3 &mdash; Harbour crane overload alarm</h2>\n'
B += P('A small jib crane on the pier at Ullapool lifts creels and boxes of catch from fishing boats. Its jib is held up by a mild steel tie bar. The harbour wants the tie bar sized correctly and an alarm that sounds if the crane is overloaded.')
B += P('A <strong>jib crane</strong> has an upright <strong>mast</strong> and a horizontal arm, the <strong>jib</strong>, that the load hangs from. A <strong>tie bar</strong> from the top of the mast to the end of the jib holds the jib up, so the tie bar is in <strong>tension</strong>.')
B += img('dc3-jib-crane.jpg', 'A steel jib crane on a harbour pier: an upright mast, a horizontal jib, a tie bar from the top of the mast to the end of the jib with strain gauges on it, and a yellow fish box hanging from the jib beside a fishing boat', 'The harbour jib crane', 408)
B += SPEC('At the crane&rsquo;s safe working load, the tension in the tie bar is 24 kN.',
          'The tie bar must have a factor of safety of at least 6.',
          'An active and a passive strain gauge (each 120 &Omega; unstrained) are bonded to the tie bar. The active gauge&rsquo;s resistance rises by 0.20 &Omega; for every 1.0 &times; 10<sup>&minus;4</sup> of strain.',
          'An alarm must sound when the tension reaches the safe working load. The gauges are in the circuit from Section 8 (5.0 V supply, 1.0 k&Omega; resistors, difference amplifier with a gain of 330).')
B += ASSIGN('dc3', '&#x1F3D7;&#xFE0F;', 'Challenge 3 &mdash; Crane overload alarm', [
 dict(key='hmat-dc3a', q='a) <strong>Design the tie.</strong> Calculate the minimum diameter of the tie bar, and choose a practical size.',
      a=C('&sigma;<sub>sw</sub> = 430 &divide; 6 = ' + tr(430 / 6) + ' ' + N2, 'A = 24 000 &divide; ' + tr(430 / 6) + ' = ' + tr(Ad) + ' mm<sup>2</sup>', 'd = &radic;(4A &divide; &pi;) = ' + tr(dd3) + ' mm') + F('minimum d = ' + sf(dd3) + ' mm; choose 22 mm'), sym=SY),
 dict(key='hmat-dc3b', q='b) <strong>Design the alarm.</strong> For your tie bar, calculate the strain at the safe working load, the resistance of the active gauge, and the output voltage of the difference amplifier at which the alarm must switch on. Describe how a comparator could be used to sound the alarm.',
      a=C('For a 22 mm bar: A = ' + tr(A22) + ' mm<sup>2</sup>, &sigma; = 24 000 &divide; ' + tr(A22) + ' = ' + tr(s22) + ' ' + N2, '&epsilon; = ' + tr(s22) + ' &divide; 196 000 = ' + tr(e22 * 1e4, 3) + ' &times; 10<sup>&minus;4</sup>', 'R = 120 + 0.20 &times; ' + tr(e22 * 1e4, 3) + ' = ' + tr(R22, 3) + ' &Omega;', 'V<sub>2</sub> &minus; V<sub>1</sub> = 5.0 &times; ' + tr(R22, 3) + ' &divide; ' + tr(1000 + R22, 3) + ' &minus; 5.0 &times; 120 &divide; 1120 = ' + tr((V2 - V1) * 1000, 3) + ' mV', 'V<sub>out</sub> = 330 &times; ' + tr(V2 - V1, 6) + ' = ' + tr(Vo, 3) + ' V') + F('Alarm at V<sub>out</sub> &asymp; ' + sf(Vo) + ' V (for a 22 mm bar)') + NOTE('Feed V<sub>out</sub> into a comparator whose reference is set to about ' + sf(Vo) + ' V by a voltage divider (or potentiometer, to allow calibration). When the amplifier output rises above the reference, the comparator output switches and drives the alarm through a transistor.'), minh=120, sym=SY),
 dict(key='hmat-dc3c', q='c) <strong>Test and evaluate.</strong> Describe how the alarm could be tested and calibrated safely, and evaluate your design against the specification.',
      a='<p>E.g. lift a series of known test masses up to the safe working load, recording V<sub>out</sub> each time to check it rises in proportion; adjust the reference so the alarm sounds at the SWL; test regularly. Evaluation: the tie meets the FoS of 6; the passive gauge removes temperature effects (important outdoors); consider waterproofing the gauges and protecting the bar from sea-spray corrosion, and possibly a warning at 90% of the SWL.</p>', minh=90),
], intro='')

TOC_SUB = [('dc1', 'Challenge 1 &mdash; Highland zip wire'), ('dc2', 'Challenge 2 &mdash; Build your own tensile test'), ('dc3', 'Challenge 3 &mdash; Crane overload alarm')]

OUTCOMES = [
 # (outcome, section anchor)
 ('describe a tensile test and identify the elastic and plastic regions, yield point, ultimate tensile load and fracture on a load&ndash;extension graph', 'section-1'),
 ('describe what happens when a load is applied and then removed in the elastic and plastic regions', 'section-1'),
 ('describe strength, elasticity, plasticity, ductility, brittleness and malleability, and recognise them on a graph', 'section-2'),
 ('calculate stress and strain for solid, hollow and rectangular sections, rearranging the formulae where needed', 'section-3'),
 ('read yield stress, yield strain and ultimate tensile stress from a stress&ndash;strain graph and compare materials from their graphs', 'section-4'),
 ('calculate Young&rsquo;s modulus from data or a graph, and use it to identify a material and find stress, strain, force or change in length', 'section-5'),
 ('calculate elastic strain energy using E<sub>s</sub> = &frac12;Fx', 'section-6'),
 ('describe the causes of structural failure and the factors that affect the choice of factor of safety', 'section-7'),
 ('use the data booklet to choose a material for a member in tension or compression', 'section-7'),
 ('calculate factor of safety, and use it to find safe working stress, load or member size, including pre-tightened bolts', 'section-7'),
 ('explain how strain gauges work, including the purpose of a passive gauge, and calculate the output of a strain gauge circuit', 'section-8'),
]
