# -*- coding: utf-8 -*-
"""Encrypt answers_plain.html into higher/mechanisms/materials/answers.html.
Usage: SITE=/path/to/unzipped/site python3 answers.py OUTDIR   (password young-modulus)
Shell: the site's higher/electronics/analogue/answers.html (same as the other Higher topics)."""
import os, re, sys, json, base64
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
from cryptography.hazmat.primitives import hashes
D = os.path.dirname(os.path.abspath(__file__))
OUT = sys.argv[1]; SITE = os.environ.get('SITE', '/home/claude/work/engineering-science')
PW = 'young-modulus'
plain = open(D + '/answers_plain.html', encoding='utf-8').read()
salt, iv, it = os.urandom(16), os.urandom(12), 200000
key = PBKDF2HMAC(algorithm=hashes.SHA256(), length=32, salt=salt, iterations=it).derive(PW.encode())
ct = AESGCM(key).encrypt(iv, plain.encode('utf-8'), None)
b = lambda x: base64.b64encode(x).decode()
blob = json.dumps({'it': it, 's': b(salt), 'i': b(iv), 'c': b(ct)})
s = open(SITE + '/higher/electronics/analogue/answers.html', encoding='utf-8').read()
s = re.sub(r'var ESS_ANSWERS = \{.*?\};', lambda m: 'var ESS_ANSWERS = ' + blob + ';', s, count=1, flags=re.S)
for a, c in [("var KEY = 'ess-answers-pw-higher-analogue';", "var KEY = 'ess-answers-pw-higher-materials';"),
             ('<title>Answers &mdash; Higher Analogue Electronics', '<title>Answers &mdash; Higher Materials'),
             ('<h1 class="hero-title">Analogue Electronics &mdash; Answers</h1>', '<h1 class="hero-title">Materials &mdash; Answers</h1>'),
             ('<a href="index.html">Analogue Electronics</a>', '<a href="index.html">Materials</a>'),
             ('Higher &middot; Electronics and Control', 'Higher &middot; Mechanisms and Structures')]:
    assert a in s, a; s = s.replace(a, c)
CSS = ('.sqrt{display:inline-flex;align-items:flex-start;white-space:nowrap}.sqrt-sign{font-size:1.15em;line-height:1}'
       '.sqrt-in{border-top:1.6px solid currentColor;padding:1px 2px 0 3px;margin-top:2px;line-height:1.25}'
       '.frac{display:inline-flex;flex-direction:column;align-items:center;vertical-align:middle;margin:0 3px;line-height:1.2}'
       '.frac-n{border-bottom:1.5px solid currentColor;padding:0 3px}.frac-d{padding:0 3px}.marks{float:right;font-weight:700;color:#6b7280;font-size:12px}'
       '.ans-a svg,.ans-q svg{max-width:100%;height:auto}')
s = s.replace('</style>', CSS + '\n  </style>', 1)
print('leftover analogue mentions:', len(re.findall('nalogue', s)))
os.makedirs(OUT + '/higher/mechanisms/materials', exist_ok=True)
open(OUT + '/higher/mechanisms/materials/answers.html', 'w', encoding='utf-8', newline='\n').write(s)
print('ok', len(s))
