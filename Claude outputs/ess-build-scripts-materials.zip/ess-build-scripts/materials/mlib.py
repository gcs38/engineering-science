# -*- coding: utf-8 -*-
"""Graph and diagram primitives for Higher Materials (same palette as structlib)."""
import math
INK = '#1e293b'; RED = '#dc2626'; BLUE = '#2563eb'; GREEN = '#15803d'; ORANGE = '#ea580c'; PURPLE = '#7c3aed'
GRID = '#e2e8f0'; AX = '#334155'; MUTED = '#64748b'
EL = '#fed7aa'; PL = '#bbf7d0'
FONT = 'Arial,Helvetica,sans-serif'

def f(x): return ('%.1f' % x).rstrip('0').rstrip('.')
def T(x, y, s, anchor='middle', size=12, col=INK, weight=400, italic=False, rot=None):
    r = ' transform="rotate(%d %s %s)"' % (rot, f(x), f(y)) if rot is not None else ''
    return '<text x="%s" y="%s" text-anchor="%s" font-family="%s" font-size="%s" font-weight="%s" fill="%s"%s%s>%s</text>' % (
        f(x), f(y), anchor, FONT, size, weight, col, ' font-style="italic"' if italic else '', r, s)
def L(x1, y1, x2, y2, col=INK, w=1.5, dash=None):
    return '<line x1="%s" y1="%s" x2="%s" y2="%s" stroke="%s" stroke-width="%s"%s/>' % (f(x1), f(y1), f(x2), f(y2), col, w, ' stroke-dasharray="%s"' % dash if dash else '')
def arrowhead(x, y, ang, col=AX, s=8):
    a = math.radians(ang)
    p1 = (x - s * math.cos(a) + s * 0.45 * math.sin(a), y - s * math.sin(a) - s * 0.45 * math.cos(a))
    p2 = (x - s * math.cos(a) - s * 0.45 * math.sin(a), y - s * math.sin(a) + s * 0.45 * math.cos(a))
    return '<polygon points="%s,%s %s,%s %s,%s" fill="%s"/>' % (f(x), f(y), f(p1[0]), f(p1[1]), f(p2[0]), f(p2[1]), col)
def ARROW(x1, y1, x2, y2, col=AX, w=1.8):
    ang = math.degrees(math.atan2(y2 - y1, x2 - x1))
    return L(x1, y1, x2, y2, col, w) + arrowhead(x2, y2, ang, col)
def svg(w, h, body, title=''):
    return '<svg viewBox="0 0 %d %d" width="%d" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="%s" style="max-width:100%%;height:auto;">%s</svg>' % (w, h, w, title, body)
def path(pts, col, w=2.6, fill='none', dash=None):
    d = 'M' + ' L'.join('%s %s' % (f(x), f(y)) for x, y in pts)
    return '<path d="%s" fill="%s" stroke="%s" stroke-width="%s" stroke-linejoin="round" stroke-linecap="round"%s/>' % (d, fill, col, w, ' stroke-dasharray="%s"' % dash if dash else '')
def poly(pts, fill, op=1):
    return '<polygon points="%s" fill="%s" fill-opacity="%s"/>' % (' '.join('%s,%s' % (f(x), f(y)) for x, y in pts), fill, op)
def dot(x, y, col=INK, r=4.5): return '<circle cx="%s" cy="%s" r="%s" fill="%s"/>' % (f(x), f(y), r, col)

def tw(s, size):
    """rough width of a text string in px (for laying out SVG fractions)"""
    import re as _re
    s = _re.sub(r'<[^>]+>', '', s)
    return len(s) * size * 0.56

def FRAC(x, y, num, den, size=15, col=INK, weight=700):
    """stacked fraction whose bar is centred on (x, y); returns (svg, width)"""
    w = max(tw(num, size), tw(den, size)) + 6
    s = T(x, y - 5, num, 'middle', size, col, weight) + L(x - w / 2, y, x + w / 2, y, col, 1.5) + T(x, y + size + 1, den, 'middle', size, col, weight)
    return s, w

def EQ(x, y, lhs, num, den, size=15, col=INK, after=''):
    """'lhs = num/den after' with the fraction stacked; (x, y) is the left end, y the fraction bar"""
    s = T(x, y + size * 0.35, lhs + ' =', 'start', size, col, 700) if lhs else ''
    fx = x + (tw(lhs + ' = ', size) + 4 if lhs else 0)
    fr, w = FRAC(fx + max(tw(num, size), tw(den, size)) / 2 + 3, y, num, den, size, col)
    s += fr
    if after: s += T(fx + w + 6, y + size * 0.35, after, 'start', size, col, 700)
    return s

def RING(cx, cy, R, r, fill='#cbd5e1', stroke=INK):
    """a ring with a see-through hole (even-odd fill), so the hole matches whatever is behind it"""
    d = 'M %s %s a %s %s 0 1 0 %s 0 a %s %s 0 1 0 %s 0 Z M %s %s a %s %s 0 1 0 %s 0 a %s %s 0 1 0 %s 0 Z' % (
        f(cx - R), f(cy), R, R, 2 * R, R, R, -2 * R, f(cx - r), f(cy), r, r, 2 * r, r, r, -2 * r)
    return '<path d="%s" fill="%s" fill-rule="evenodd" stroke="%s" stroke-width="2"/>' % (d, fill, stroke)

def SQRING(cx, cy, S, s, fill='#cbd5e1', stroke=INK):
    d = 'M %s %s h %s v %s h %s Z M %s %s h %s v %s h %s Z' % (f(cx - S / 2), f(cy - S / 2), S, S, -S, f(cx - s / 2), f(cy - s / 2), s, s, -s)
    return '<path d="%s" fill="%s" fill-rule="evenodd" stroke="%s" stroke-width="2"/>' % (d, fill, stroke)

def DIM(x1, y1, x2, y2, lab, col=RED, size=12, off=(0, -6), anchor='middle'):
    """dimension line with arrowheads at both ends"""
    ang = math.degrees(math.atan2(y2 - y1, x2 - x1))
    return (L(x1, y1, x2, y2, col, 1.3) + arrowhead(x2, y2, ang, col, 7) + arrowhead(x1, y1, ang + 180, col, 7) +
            (T((x1 + x2) / 2 + off[0], (y1 + y2) / 2 + off[1], lab, anchor, size, col, 700) if lab else ''))

def RECT(x, y, w, h, fill='#e2e8f0', stroke=INK, sw=1.6, rx=0):
    return '<rect x="%s" y="%s" width="%s" height="%s" rx="%s" fill="%s" stroke="%s" stroke-width="%s"/>' % (f(x), f(y), f(w), f(h), rx, fill, stroke, sw)

def HATCH(x1, x2, y, down=True, col='#64748b'):
    s = L(x1, y, x2, y, INK, 2)
    x = x1 + 4
    while x < x2:
        s += L(x, y, x - 8, y + (10 if down else -10), col, 1)
        x += 9
    return s

# ------------------------------------------------------------ material curves
def curve(ey, sy, eu, su, ef, sf, n=60, yp=0.0):
    """stress-strain (or load-extension) points: straight to yield (ey, sy), rising to the ultimate (eu, su), falling to fracture (ef, sf)"""
    pts = [(0, 0), (ey, sy)]
    if eu > ey:
        for i in range(1, n + 1):
            t = i / n; e = ey + (eu - ey) * t
            pts.append((e, sy + (su - sy) * (1 - (1 - t) ** 2.2)))
    if ef > eu:
        for i in range(1, n + 1):
            t = i / n; e = eu + (ef - eu) * t
            pts.append((e, su - (su - sf) * t ** 2))
    return pts

class Graph:
    """axes with optional grid; data coordinates mapped into a plot box"""
    def __init__(self, W, H, xmax, ymax, xl, yl, xt=None, yt=None, grid=True, ml=58, mb=46, mt=18, mr=24, xfmt=None, yfmt=None, minor=None):
        self.W, self.H, self.xmax, self.ymax = W, H, xmax, ymax
        self.x0, self.y0, self.x1, self.y1 = ml, H - mb, W - mr, mt
        b = ''
        if grid and minor:
            mx, my = minor
            v = mx
            while v < xmax - 1e-9: b += L(self.X(v), self.y0, self.X(v), self.y1, '#f1f5f9', 1); v += mx
            v = my
            while v < ymax - 1e-9: b += L(self.x0, self.Y(v), self.x1, self.Y(v), '#f1f5f9', 1); v += my
        if xt:
            for v in xt:
                if grid and v > 0: b += L(self.X(v), self.y0, self.X(v), self.y1, GRID, 1)
                b += L(self.X(v), self.y0, self.X(v), self.y0 + 5, AX, 1.2) + T(self.X(v), self.y0 + 18, xfmt(v) if xfmt else f(v), size=11, col=MUTED)
        if yt:
            for v in yt:
                if grid and v > 0: b += L(self.x0, self.Y(v), self.x1, self.Y(v), GRID, 1)
                b += L(self.x0 - 5, self.Y(v), self.x0, self.Y(v), AX, 1.2) + T(self.x0 - 8, self.Y(v) + 4, yfmt(v) if yfmt else f(v), 'end', 11, MUTED)
        b += ARROW(self.x0, self.y0, self.x1 + 12, self.y0) + ARROW(self.x0, self.y0, self.x0, self.y1 - 10)
        b += T((self.x0 + self.x1) / 2, H - 8, xl, size=12, col=INK, weight=700)
        b += T(14, (self.y0 + self.y1) / 2, yl, size=12, col=INK, weight=700, rot=-90)
        self.axes = b; self.body = ''
    def X(self, v): return self.x0 + (self.x1 - self.x0) * v / self.xmax
    def Y(self, v): return self.y0 - (self.y0 - self.y1) * v / self.ymax
    def P(self, pts): return [(self.X(a), self.Y(b)) for a, b in pts]
    def add(self, s): self.body += s; return self
    def line(self, pts, col=BLUE, w=2.6, dash=None): return self.add(path(self.P(pts), col, w, dash=dash))
    def fill(self, pts, col, op=0.8): return self.add(poly(self.P(pts), col, op))
    def pt(self, x, y, lab='', col=INK, dx=0, dy=-10, anchor='middle', size=13):
        return self.add(dot(self.X(x), self.Y(y), col) + (T(self.X(x) + dx, self.Y(y) + dy, lab, anchor, size, col, 700) if lab else ''))
    def text(self, x, y, s, anchor='middle', size=12, col=INK, weight=400, italic=False):
        return self.add(T(self.X(x), self.Y(y), s, anchor, size, col, weight, italic))
    def hdash(self, y, x2, col=MUTED, lab=None):
        self.add(L(self.x0, self.Y(y), self.X(x2), self.Y(y), col, 1.3, '5 4'))
        if lab: self.add(T(self.x0 + 4, self.Y(y) - 5, lab, 'start', 11, col, 700))
        return self
    def vdash(self, x, y2, col=MUTED, lab=None):
        self.add(L(self.X(x), self.y0, self.X(x), self.Y(y2), col, 1.3, '5 4'))
        if lab: self.add(T(self.X(x), self.y0 + 32, lab, 'middle', 11, col, 700))
        return self
    def svg(self, title=''): return svg(self.W, self.H, self.axes + self.body, title)

def fig(svgtxt, cap='', w=520):
    return '      <figure class="circuit-figure" style="max-width:%dpx;margin:16px auto;">%s%s</figure>\n' % (w, svgtxt, ('<figcaption>%s</figcaption>' % cap) if cap else '')
def mini(svgtxt, cap='', w=380):
    return '            <figure class="circuit-figure mini-div" style="max-width:%dpx;margin:6px auto 10px;">%s%s</figure>\n' % (w, svgtxt, ('<figcaption>%s</figcaption>' % cap) if cap else '')
def row(*figs):
    return '      <div class="fig-row">%s</div>\n' % ''.join(x.replace('margin:16px auto;', 'margin:0 auto;') for x in figs)
def img(src, alt, cap='', w=420):
    return '      <figure class="circuit-figure" style="max-width:%dpx;margin:16px auto;"><img src="images/%s" alt="%s" style="width:100%%;height:auto;border-radius:8px;display:block;">%s</figure>\n' % (w, src, alt, ('<figcaption>%s</figcaption>' % cap) if cap else '')
