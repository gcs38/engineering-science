# -*- coding: utf-8 -*-
"""Build higher/mechanisms/materials/course-notes.html and the plain answers.
Usage: python3 assemble.py "11 November 2026, 13:40" OUTDIR
Template: the Higher Structures and Forces page (source-course-notes-2026-11-08.html, same Higher skeleton)."""
import sys, os, re, shutil, glob, html as H
D = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, D); os.chdir(D)
import helpers
import content1, content2, content3, widget
STAMP, OUT = sys.argv[1], sys.argv[2]
src = open('source-course-notes-2026-11-08.html', encoding='utf-8').read()

head = src[:src.index('      <div class="key-point"><strong>Before you start.')]
head = re.sub(r'Last updated: [^<]*<', 'Last updated: %s<' % STAMP, head)
for a, b in [('<title>Structures and Forces &mdash; Higher Course Notes', '<title>Materials &mdash; Higher Course Notes'),
             ('Higher &middot; Mechanisms and Structures &rsaquo; Structures and Forces', 'Higher &middot; Mechanisms and Structures &rsaquo; Materials'),
             ('&#x1F3D7;&#xFE0F; Structures and Forces &mdash; Course Notes', '&#x1F9F1; Materials &mdash; Course Notes'),
             ('Resolving forces, equilibrium, beam reactions with UDLs, and nodal analysis of frames', 'Material properties, tensile testing, stress&ndash;strain graphs, Young&rsquo;s modulus, strain energy, factor of safety and strain gauges'),
             ('<a href="index.html">Structures and Forces</a> &rsaquo;', '<a href="index.html">Materials</a> &rsaquo;'),
             ('&larr; Back to Structures and Forces', '&larr; Back to Materials')]:
    assert a in head, a; head = head.replace(a, b)
CSS = r"""
    /* worked examples: the standard ESS grey box and teal numbered steps, with each equation on its own larger line */
    .worked-example .we-intro { font-size:14px; margin:0 0 12px; color:var(--gray-700); line-height:1.6; }
    .worked-example .we-fig { text-align:center; margin:4px 0 12px; }
    .worked-example .we-fig svg { max-width:100%; height:auto; }
    .worked-example .step-content .eq { font-size:17px; line-height:2.1; color:var(--gray-900); padding-left:4px; }
    .worked-example .step-content > strong { display:block; font-size:13px; margin-bottom:2px; }
    .worked-example .ans-final, .stepper .ans-final { font-weight:700; color:var(--teal-800); }
    .sqrt { display:inline-flex; align-items:flex-start; white-space:nowrap; }
    .sqrt-sign { font-size:1.15em; line-height:1; margin-right:-1px; }
    .sqrt-in { border-top:1.6px solid currentColor; padding:1px 2px 0 3px; margin-top:2px; line-height:1.25; }
    .frac { display:inline-flex; flex-direction:column; align-items:center; vertical-align:middle; margin:0 3px; line-height:1.25; }
    .frac-n { border-bottom:1.6px solid currentColor; padding:0 4px; }
    .frac-d { padding:0 4px; }
    .formula-box .formula { font-size:22px !important; }
    .formula-box .formula.formula-long { font-size:15px !important; white-space:nowrap; }
    .formula-box:has(.formula-long) { overflow-x:auto; }
    .marks { float:right; font-weight:700; color:var(--gray-500); font-size:12px; margin-left:8px; }
    .fig-row { display:grid; grid-template-columns:repeat(auto-fit,minmax(240px,1fr)); gap:14px; align-items:end; margin:14px 0; }
    .circuit-figure svg { max-width:100%; height:auto; }
    .tsim-wrap { position:relative; width:100%; overflow:hidden; background:#f8fafc; }
    .tsim-frame { position:absolute; top:0; left:0; width:960px; height:540px; border:0; transform-origin:0 0; }
    @media print { .tsim-wrap { display:none; } }
    .pair-row { display:flex; justify-content:center; align-items:stretch; gap:14px; flex-wrap:wrap; margin:16px 0; }
    .pair-row figure { margin:0; display:flex; flex-direction:column; align-items:center; }
    .pair-row img, .pair-row svg { height:200px !important; width:auto !important; max-width:100%; border-radius:8px; display:block; }
    .prac-badge { display:inline-block; font-size:12px; font-weight:700; color:#9a3412; background:#ffedd5; border:1px solid #fdba74; border-radius:999px; padding:2px 10px; margin-left:6px; vertical-align:middle; white-space:nowrap; }
    /* step-through worked examples: same grey box and teal steps as the other worked examples */
    .stepper .stepper-line { display:none; gap:12px; align-items:flex-start; font-size:16px; line-height:1.9; padding:6px 8px; border-radius:6px; color:var(--gray-600); }
    .stepper .stepper-line.on { display:flex; }
    .stepper .stepper-line.cur { color:var(--gray-900); background:var(--teal-50,#f0fdfa); }
    .stepper-n { flex:0 0 24px; height:24px; border-radius:50%; background:var(--teal-400); color:#fff; font-weight:700; font-size:11px; display:flex; align-items:center; justify-content:center; margin-top:4px; }
    .stepper-ctrl { display:flex; gap:8px; align-items:center; justify-content:center; margin-top:10px; flex-wrap:wrap; }
    .stepper-count { font-size:12.5px; color:var(--gray-500); min-width:90px; text-align:center; }
    @media print { .stepper .stepper-line { display:flex!important; } .stepper-ctrl { display:none!important; } }
"""
CSS += widget.CSS
for k in ['.we-hand .we-intro', '.stepper {']:   # keep the template's own rules if it already has them
    pass
head = head.replace('  </style>\n</head>', CSS + '  </style>\n<script>window.ESS_PHOTOS = true;</script>\n</head>', 1)
assert 'ESS_PHOTOS' in head and STAMP in head
assert 'Structures and Forces' not in head.split('<body')[1], 'leftover in head'

tail = src[src.index('      <hr class="divider">\n\n      <div class="controls-bar">'):]
rep = [('<a href="../materials/index.html" class="ctrl-btn', '<a href="../../index.html" class="ctrl-btn'),
       ("const PUPIL_NAME_KEY = 'hsf-pupil-name';", "const PUPIL_NAME_KEY = 'hmat-pupil-name';"),
       ("'Engineering Science Scotland - Higher Structures and Forces'", "'Engineering Science Scotland - Higher Materials'"),
       ("'Higher Structures and Forces \\u2014 All my answers'", "'Higher Materials \\u2014 All my answers'"),
       ("'Higher-Structures-and-Forces-All-My-Answers.pdf'", "'Higher-Materials-All-My-Answers.pdf'")]
for a, b in rep:
    assert a in tail, a; tail = tail.replace(a, b)
tail = tail.replace('Next section &#x2192;</a>', 'Higher menu &#x2192;</a>', 1)
pan = ',\n'.join("  ['%s', '%s']" % (pid, H.unescape(lbl).replace("'", "\\u2019").replace('\u2014', '\\u2014').replace('\u2013', '\\u2013')) for pid, lbl in helpers.PANELS)
tail = re.sub(r'const ALL_TASK_PANELS = \[.*?\n\];', lambda m: 'const ALL_TASK_PANELS = [\n' + pan + '\n];', tail, count=1, flags=re.S)
toc = ''.join('    <a href="#section-%d" onclick="closeToc()">Section %d: %s</a>\n' % (i, i, t) for i, t in enumerate(helpers.SECTIONS, 1))
toc += ''.join('    <a href="#%s" class="toc-sub" onclick="closeToc()">%s</a>\n' % ab for ab in content3.TOC_SUB)
tail = re.sub(r'(<nav class="toc-list" id="tocList">\n).*?(  </nav>)', lambda m: m.group(1) + toc + m.group(2), tail, count=1, flags=re.S)
STEP_JS = r"""<script>
/* Step-through worked examples: Next / Back reveal the working one line at a time */
document.querySelectorAll('.stepper').forEach(function (st) {
  var max = +st.dataset.max, cur = 1;
  function show() {
    st.querySelectorAll('.stepper-line').forEach(function (l) { var n = +l.dataset.step; l.classList.toggle('on', n <= cur); l.classList.toggle('cur', n === cur); });
    st.querySelector('.stepper-count').textContent = 'Step ' + cur + ' of ' + max;
    st.querySelector('[data-act=prev]').disabled = cur === 1; st.querySelector('[data-act=next]').disabled = cur === max;
  }
  st.querySelector('[data-act=prev]').addEventListener('click', function () { if (cur > 1) { cur--; show(); } });
  st.querySelector('[data-act=next]').addEventListener('click', function () { if (cur < max) { cur++; show(); } });
  st.querySelector('[data-act=all]').addEventListener('click', function () { cur = max; show(); });
  show();
});
</script>
"""
TSIM_JS = r"""<script>
/* Tensile test simulator demonstrations: compact view in the page, full simulator in a new tab */
(function () {
  var siteJs = document.querySelector('script[src*="js/site.js"]');
  var root = siteJs ? siteJs.getAttribute('src').replace(/js\/site\.js.*$/, '') : '../../../';
  var sim = new URL(root + 'simulators/mat-tensile-test.html', location.href).href;
  document.querySelectorAll('iframe[data-tsim]').forEach(function (f) { f.src = sim + '?view=1&' + f.getAttribute('data-tsim'); });
  /* the simulator is laid out at 960 x 540 and scaled to fit the column, so the whole of it is always visible */
  function fit() {
    document.querySelectorAll('.tsim-wrap').forEach(function (w) {
      var k = Math.min(1, w.clientWidth / 960), f = w.querySelector('iframe');
      f.style.transform = 'scale(' + k + ')'; w.style.height = Math.round(540 * k) + 'px';
    });
  }
  fit(); window.addEventListener('resize', fit);
  document.querySelectorAll('a.sim-open[data-tsim]').forEach(function (a) { a.href = sim + '?' + a.getAttribute('data-tsim'); });
})();
</script>
"""
tail = tail.replace('</body>', STEP_JS + TSIM_JS + '</body>', 1)
body = '<!-- Higher Materials course notes body: built by ess-build-scripts/materials -->\n' + content1.B + content2.B + content3.B
page = head + body + '\n' + tail
page = helpers.fixunits(page)
left = [re.sub(r'\s+', ' ', page[m.start() - 70:m.start() + 30]) for m in re.finditer('Structures and Forces', page)]
print('Structures and Forces mentions (should be none):', left)
os.makedirs(OUT + '/higher/mechanisms/materials/images', exist_ok=True)
for f in glob.glob(D + '/img/*'): shutil.copy(f, OUT + '/higher/mechanisms/materials/images/')
open(OUT + '/higher/mechanisms/materials/course-notes.html', 'w', encoding='utf-8', newline='\n').write(page)

ah = ''
for label, items in helpers.ANS:
    ah += '<div class="ans-section"><h2>%s</h2>' % label
    for key, q, a in items:
        ah += '<div class="ans" data-key="%s"><div class="ans-q">%s</div><div class="ans-a">%s</div></div>' % (key, re.sub(r'<figure.*?</figure>', '', q, flags=re.S), a)
    ah += '</div>'
open(D + '/answers_plain.html', 'w', encoding='utf-8').write(helpers.fixunits(ah))
keys = re.findall(r'data-key="([^"]+)"', body)
assert len(keys) == len(set(keys)), [k for k in keys if keys.count(k) > 1]
print('ok', len(page), 'keys', len(keys), 'sections', len(helpers.SECTIONS), 'panels', len(helpers.PANELS))
