# -*- coding: utf-8 -*-
"""Tensile test explorer: pick a material, drag the load along its stress-strain curve, then 'remove the load'."""
CSS = r"""
    .tt { background:var(--white,#fff); border:1px solid var(--gray-200); border-left:4px solid #2563eb; border-radius:10px; padding:14px 16px; margin:18px 0; }
    .tt-title { font-weight:700; color:var(--teal-800); margin-bottom:8px; }
    .tt-ctrl { display:flex; flex-wrap:wrap; gap:10px 16px; align-items:center; font-size:13.5px; margin-bottom:8px; }
    .tt-ctrl select, .tt-ctrl button { font:inherit; padding:5px 10px; border-radius:6px; border:1px solid var(--gray-300,#cbd5e1); background:#fff; cursor:pointer; }
    .tt-ctrl input[type=range] { flex:1 1 220px; }
    .tt svg { width:100%; height:auto; display:block; }
    .tt-read { display:grid; grid-template-columns:repeat(auto-fit,minmax(150px,1fr)); gap:8px; margin-top:8px; }
    .tt-read div { background:#f8fafc; border:1px solid var(--gray-200); border-radius:8px; padding:6px 10px; font-size:13px; }
    .tt-read b { display:block; font-size:15px; color:var(--gray-900,#0f172a); }
    .tt-msg { margin-top:8px; font-size:14px; padding:8px 10px; border-radius:8px; background:#eff6ff; }
    @media print { .tt { display:none; } }
"""

HTML = r"""
      <div class="tt" id="ttWidget">
        <div class="tt-title">&#x1F9EA; Tensile test explorer</div>
        <div class="tt-ctrl">
          <label>Material <select id="ttMat">
            <option value="ms">Mild steel</option><option value="al">Aluminium alloy</option>
            <option value="ci">Cast iron</option><option value="abs">ABS plastic</option></select></label>
          <label>View <select id="ttZoom"><option value="all">Whole test</option><option value="el">Zoom in on the start</option></select></label>
          <button type="button" id="ttRemove">Remove the load</button>
        </div>
        <div class="tt-ctrl"><span>Pull harder &rarr;</span><input type="range" id="ttPull" min="0" max="1000" value="0" aria-label="How far through the test"></div>
        <svg id="ttSvg" viewBox="0 0 600 320" role="img" aria-label="Stress-strain graph for the chosen material"></svg>
        <div class="tt-read">
          <div>Stress<b id="ttS">0 Nmm<sup>&minus;2</sup></b></div>
          <div>Strain<b id="ttE">0</b></div>
          <div>Region<b id="ttR">&mdash;</b></div>
        </div>
        <div class="tt-msg" id="ttMsg">Move the slider to load the specimen. Then press <strong>Remove the load</strong> to see whether it goes back to its original length.</div>
      </div>
<script>
(function () {
  /* E in Nmm-2; yield, UTS and fracture stresses from the data booklet where it gives them; strains at UTS and fracture are typical values */
  var M = {
    ms:  { n:'Mild steel', E:196000, sy:220, su:430, eu:0.15, ef:0.26, sf:350 },
    al:  { n:'Aluminium alloy', E:70000, sy:250, su:300, eu:0.06, ef:0.10, sf:270 },
    ci:  { n:'Cast iron', E:120000, sy:null, su:140, eu:0.00117, ef:0.00117, sf:140 },
    abs: { n:'ABS plastic', E:2600, sy:55, su:60, eu:0.04, ef:0.10, sf:45 }
  };
  var svg = document.getElementById('ttSvg'), pull = document.getElementById('ttPull');
  var W = 600, H = 320, x0 = 64, y0 = 278, x1 = 584, y1 = 16, removed = false;
  function pts(m) {
    var a = [[0, 0]], ey;
    if (m.sy === null) { a.push([m.ef, m.sf]); return a; }
    ey = m.sy / m.E; a.push([ey, m.sy]);
    for (var i = 1; i <= 80; i++) { var t = i / 80; a.push([ey + (m.eu - ey) * t, m.sy + (m.su - m.sy) * (1 - Math.pow(1 - t, 2.2))]); }
    for (i = 1; i <= 60; i++) { t = i / 60; a.push([m.eu + (m.ef - m.eu) * t, m.su - (m.su - m.sf) * t * t]); }
    return a;
  }
  function at(a, f, m) {                    /* slider: first 30% covers the elastic region, the rest the plastic region */
    var ef = a[a.length - 1][0], ey = m.sy ? m.sy / m.E : ef;
    var e = m.sy ? (f <= 0.3 ? f / 0.3 * ey : ey + (f - 0.3) / 0.7 * (ef - ey)) : f * ef;
    for (var i = 1; i < a.length; i++) if (a[i][0] >= e) { var p = a[i - 1], q = a[i], t = (q[0] - p[0]) ? (e - p[0]) / (q[0] - p[0]) : 0; return [e, p[1] + (q[1] - p[1]) * t]; }
    return a[a.length - 1];
  }
  function sig(x) { return x === 0 ? '0' : x >= 100 ? Math.round(x).toString() : x.toPrecision(2); }
  function tick(v) { v = v * 1000; return v === 0 ? '0' : v >= 10 ? Math.round(v).toString() : (+v.toPrecision(2)).toString(); }
  function strain(x) { return x === 0 ? '0' : (x * 1000).toPrecision(2) + ' \u00D7 10\u207B\u00B3'; }
  function draw() {
    var m = M[document.getElementById('ttMat').value], a = pts(m), zoom = document.getElementById('ttZoom').value === 'el';
    var emax = zoom ? (m.sy ? 4 * m.sy / m.E : m.ef * 1.2) : a[a.length - 1][0] * 1.08, smax = 500;
    function X(e) { return x0 + (x1 - x0) * Math.min(e, emax) / emax; }
    function Y(s) { return y0 - (y0 - y1) * s / smax; }
    var s = '', i;
    for (i = 0; i <= 5; i++) { var v = smax * i / 5; s += '<line x1="' + x0 + '" y1="' + Y(v) + '" x2="' + x1 + '" y2="' + Y(v) + '" stroke="#e2e8f0"/><text x="' + (x0 - 6) + '" y="' + (Y(v) + 4) + '" text-anchor="end" font-size="11" fill="#64748b">' + Math.round(v) + '</text>'; }
    for (i = 0; i <= 5; i++) { v = emax * i / 5; s += '<text x="' + X(v) + '" y="' + (y0 + 16) + '" text-anchor="middle" font-size="11" fill="#64748b">' + tick(v) + '</text>'; }
    s += '<line x1="' + x0 + '" y1="' + y0 + '" x2="' + x1 + '" y2="' + y0 + '" stroke="#334155" stroke-width="1.6"/><line x1="' + x0 + '" y1="' + y0 + '" x2="' + x0 + '" y2="' + y1 + '" stroke="#334155" stroke-width="1.6"/>';
    s += '<text x="' + ((x0 + x1) / 2) + '" y="' + (H - 4) + '" text-anchor="middle" font-size="12" font-weight="700">strain (\u00D7 10\u207B\u00B3)</text><text x="14" y="' + ((y0 + y1) / 2) + '" text-anchor="middle" font-size="12" font-weight="700" transform="rotate(-90 14 ' + ((y0 + y1) / 2) + ')">stress (Nmm\u207B\u00B2)</text>';
    var d = a.filter(function (p) { return p[0] <= emax; }).map(function (p, k) { return (k ? 'L' : 'M') + X(p[0]).toFixed(1) + ' ' + Y(p[1]).toFixed(1); }).join(' ');
    s += '<path d="' + d + '" fill="none" stroke="#cbd5e1" stroke-width="3"/>';
    var f = +pull.value / 1000, p = at(a, f, m), broken = f >= 0.999, plastic = m.sy !== null && p[1] >= m.sy - 1e-9 && p[0] > m.sy / m.E + 1e-12;
    var done = a.filter(function (q) { return q[0] <= p[0]; }).concat([p]);
    s += '<path d="' + done.filter(function (q) { return q[0] <= emax; }).map(function (q, k) { return (k ? 'L' : 'M') + X(q[0]).toFixed(1) + ' ' + Y(q[1]).toFixed(1); }).join(' ') + '" fill="none" stroke="#2563eb" stroke-width="3"/>';
    if (m.sy) s += '<line x1="' + x0 + '" y1="' + Y(m.sy) + '" x2="' + X(m.sy / m.E) + '" y2="' + Y(m.sy) + '" stroke="#ea580c" stroke-dasharray="5 4"/><text x="' + (x0 + 4) + '" y="' + (Y(m.sy) - 5) + '" font-size="11" font-weight="700" fill="#ea580c">yield stress ' + m.sy + '</text>';
    var msg, region;
    if (broken) { region = 'Fractured'; msg = m.sy === null ? 'Cast iron is <strong>brittle</strong>: it snapped at the end of a straight line with no plastic region and no warning.' : 'The specimen has <strong>fractured</strong>. Look how far it stretched before breaking &mdash; that is its ductility.'; }
    else if (!plastic) { region = p[0] === 0 ? '&mdash;' : 'Elastic'; msg = p[0] === 0 ? 'No load yet.' : 'Elastic region: stress is proportional to strain. E = &sigma; &divide; &epsilon; = ' + Math.round(m.E / 1000) + ' kNmm<sup>&minus;2</sup>.'; }
    else { region = 'Plastic'; msg = 'Plastic region: the specimen has passed its yield point and is being permanently stretched.'; }
    if (removed && !broken && p[0] > 0) {
      var set = plastic ? p[0] - p[1] / m.E : 0;
      s += '<line x1="' + X(p[0]) + '" y1="' + Y(p[1]) + '" x2="' + X(set) + '" y2="' + y0 + '" stroke="#dc2626" stroke-width="2.4" stroke-dasharray="7 5"/>';
      msg = plastic ? 'Load removed: it springs back along a line <strong>parallel to the elastic line</strong>, but keeps a permanent strain of ' + strain(set) + '. That is plastic deformation.' : 'Load removed: it goes back down the same line to zero strain &mdash; it returns to its original length. That is elastic behaviour.';
    }
    s += '<circle cx="' + X(p[0]) + '" cy="' + Y(p[1]) + '" r="6" fill="' + (broken ? '#0f172a' : '#2563eb') + '"/>';
    if (p[0] > emax) s += '<text x="' + (x1 - 4) + '" y="' + (y1 + 14) + '" text-anchor="end" font-size="11" fill="#64748b">point is off this zoomed view &rarr;</text>';
    svg.innerHTML = s;
    document.getElementById('ttS').innerHTML = sig(p[1]) + ' Nmm<sup>&minus;2</sup>';
    document.getElementById('ttE').innerHTML = strain(p[0]);
    document.getElementById('ttR').innerHTML = region;
    document.getElementById('ttMsg').innerHTML = msg;
  }
  pull.addEventListener('input', function () { removed = false; draw(); });
  document.getElementById('ttMat').addEventListener('change', function () { removed = false; pull.value = 0; draw(); });
  document.getElementById('ttZoom').addEventListener('change', draw);
  document.getElementById('ttRemove').addEventListener('click', function () { removed = true; draw(); });
  draw();
})();
</script>
"""
