# -*- coding: utf-8 -*-
"""Page-building helpers for Higher Structures and Forces (same markup as the other Higher notes)."""
import re, math, html as _html
ANS = []      # (panel label, [(key, question_html, answer_html)])
PANELS = []   # (panel id, label)
SECTIONS = []
TASKN = [0]; INVN = [0]

def sub(a, b): return '%s<sub>%s</sub>' % (a, b)
SUM = '&Sigma;'
UP, DN, LT, RT = '&uarr;', '&darr;', '&larr;', '&rarr;'
VERT = 'ΣF↑ = ΣF↓'
SFU = SUM + 'F' + UP; SFD = SUM + 'F' + DN; SFL = SUM + 'F' + LT; SFR = SUM + 'F' + RT
EQV = SFU + ' = ' + SFD
EQH = SFL + ' = ' + SFR

def fr(n, d): return '<span class="frac"><span class="frac-n">%s</span><span class="frac-d">%s</span></span>' % (n, d)
def SQ(x): return '<span class="sqrt"><span class="sqrt-sign">&radic;</span><span class="sqrt-in">%s</span></span>' % x

def sf(x, n=2):
    """round to n significant figures, written the exam way (3.0, 0.50, 670, 1700)"""
    if x == 0: return '0'
    d = n - 1 - int(math.floor(math.log10(abs(x))))
    v = round(x, d)
    if abs(v) >= 10 ** n: d = n - 1 - int(math.floor(math.log10(abs(v))))
    if d > 0: return '%.*f' % (d, v)
    return '%d' % int(round(v, d))
def tr(x, dp=2):
    """full value carried through the working, shown truncated with an ellipsis"""
    return ('%.*f' % (dp, x)) + '&hellip;'
def cosd(a): return math.cos(math.radians(a))
def sind(a): return math.sin(math.radians(a))
def tand(a): return math.tan(math.radians(a))
def atand(x): return math.degrees(math.atan(x))

def H1(title, id=None):
    SECTIONS.append(title); n = len(SECTIONS)
    return '\n      <hr class="divider">\n\n      <h1 class="notes-h1" id="section-%d">Section %d: %s</h1>\n' % (n, n, title)
def H2(t, id=None): return '      <h2 class="notes-h2"%s>%s</h2>\n' % (' id="%s"' % id if id else '', t)
def P(t): return '      <p class="notes-p">%s</p>\n' % t
def UL(*items): return '      <ul class="notes-ul">%s</ul>\n' % ''.join('<li>%s</li>' % i for i in items)
def OL(*items): return '      <ol class="notes-ul">%s</ol>\n' % ''.join('<li>%s</li>' % i for i in items)
def KP(t): return '      <div class="key-point">%s</div>\n' % t
def WARN(t): return '      <div class="warning">%s</div>\n' % t
def FB(t, cls=''):
    return '      <div class="formula-box"><div class="formula%s" style="font-size:18px;font-weight:700;color:var(--teal-800);margin:4px 0;">%s</div></div>\n' % ((' ' + cls) if cls else '', t)
def TABLE(head, rows, cls='data-table'):
    return '      <table class="%s"><tr>%s</tr>%s</table>\n' % (cls, ''.join('<th>%s</th>' % h for h in head), ''.join('<tr>%s</tr>' % ''.join('<td>%s</td>' % c for c in r) for r in rows))
def WE(title, steps):
    s = ''.join('<div class="step"><div class="step-num">%d</div><div class="step-content">%s</div></div>' % (i + 1, t) for i, t in enumerate(steps))
    return '      <div class="worked-example"><div class="worked-example-title">%s</div>%s</div>\n' % (title, s)

def WEL(title, blocks, top=None, intro=''):
    """Worked example in the standard ESS layout (grey box, teal title, numbered teal steps, as in the other
    Higher topics), with each equation on its own, larger line so fractions and symbols are easy to read.
    blocks: list of (heading or '', [lines], side_svg or None); a side of ('wide', svg) is drawn under the step."""
    out = '      <div class="worked-example"><div class="worked-example-title">%s</div>' % title
    if intro: out += '<p class="we-intro">%s</p>' % intro
    if top: out += '<div class="we-fig">%s</div>' % top
    for i, (headl, lines, side) in enumerate(blocks, 1):
        out += '<div class="step"><div class="step-num">%d</div><div class="step-content">' % i
        if headl: out += '<strong>%s</strong>' % headl
        out += ''.join('<div class="eq">%s</div>' % l for l in lines)
        if isinstance(side, tuple): out += '<div class="we-fig">%s</div>' % side[1]
        elif side: out += '<div class="we-fig">%s</div>' % side
        out += '</div></div>'
    return out + '</div>\n'

def SIMP(sim, design, title, note, height=500):
    return ('      <div class="sim-panel">\n        <div class="sim-head"><span>&#x1F9EE; %s</span><a class="sim-open" target="_blank" rel="noopener" data-sim="%s" data-design="simulators/%s">&#x270F;&#xFE0F; Open in editor &#x2197;</a></div>\n'
            '        <iframe class="sim-frame" data-sim="%s" data-design="simulators/%s" data-view="1" style="height:%dpx;" title="%s simulator: %s" loading="lazy"></iframe>\n'
            '        <p class="sim-note">%s</p>\n      </div>\n') % (title, sim, design, sim, design, height, 'NODEarama' if 'node' in sim else 'No Stress', title, note)
def CHECK(design):
    return '            <div class="sim-check-row"><a class="sim-check" target="_blank" rel="noopener" data-sim="nodearama.html" data-design="simulators/%s">&#x1F50E; Check in NODEarama &#x2197;</a></div>\n' % design

def SPEC(*items):
    roman = ['i', 'ii', 'iii', 'iv', 'v', 'vi', 'vii']
    return '      <table class="spec-table">%s</table>\n' % ''.join('<tr><th><span class="data-badge">%s</span></th><td>%s</td></tr>' % (roman[i], t) for i, t in enumerate(items))

# answer-builder symbol sets
BASE = ['&Sigma;', '&radic;', '&uarr;', '&darr;', '&larr;', '&rarr;', '&deg;']
def syms(*extra, base=True):
    toks = (BASE if base else []) + list(extra)
    toks = [_html.unescape(t) if '<' not in t else t for t in toks]
    return ' data-symbols="%s"' % _html.escape('|'.join(toks), quote=True)
FHV = ('F<sub>H</sub>', 'F<sub>V</sub>')

def C(*lines): return '<div class="ans-calc">%s</div>' % '<br>'.join(lines)
def F(t): return '<span class="ans-final">%s</span>' % t
def NOTE(t): return '<p class="ans-note">%s</p>' % t

def ASSIGN(pid, icon, label, items, intro=''):
    """items: dicts with key, q, a, and optional sym (attribute string), extra (html under the question),
    table (html replacing the answer box), minh"""
    if label.startswith('Task '):
        TASKN[0] += 1; label = re.sub(r'^Task \d*', 'Task %d' % TASKN[0], label)
    if label.startswith('Investigation'):
        INVN[0] += 1; label = re.sub(r'^Investigation( \d+)?', 'Investigation %d' % INVN[0], label)
    PANELS.append(('assignment-' + pid, label))
    body = ''; alist = []
    for it in items:
        key, q, a = it['key'], it['q'], it['a']
        body += '          <div class="task-item">\n            <div class="task-q">%s</div>\n' % q
        if it.get('extra'): body += it['extra'] + ('\n' if not it['extra'].endswith('\n') else '')
        if it.get('table'):
            body += it['table']
            if not it.get('box'):
                body += '          </div>\n'; alist.append((key, q, a)); continue
        mh = ' style="min-height:%dpx;"' % it['minh'] if it.get('minh') else ''
        body += ('            <div class="answer-label">Answer <span class="saved-indicator" id="ind-%s"></span></div>\n'
                 '            <div class="answer-box" contenteditable="true" data-key="%s" data-placeholder="Type your answer here..."%s%s></div>\n          </div>\n') % (key, key, mh, it.get('sym', ''))
        alist.append((key, q, a))
    ANS.append((label, alist))
    intro_html = ''
    if intro: intro_html = ('          %s\n' % intro) if intro.lstrip().startswith('<') else ('          <p class="notes-p" style="margin-bottom:14px;">%s</p>\n' % intro)
    return ('      <div class="assignment" id="assignment-%s">\n        <div class="assignment-header"><div class="assignment-title">%s %s</div></div>\n'
            '        <div class="assignment-body">\n%s%s        </div>\n        <div class="task-download-row">\n'
            '          <button class="task-download-btn" onclick="downloadTaskPDF(\'assignment-%s\', \'%s\')">&#x2B07;&#xFE0F; Download my answers (PDF)</button>\n'
            '        </div>\n      </div>\n') % (pid, icon, label, intro_html, body, pid, label.replace("'", "&rsquo;"))

def CELLS(head, rows):
    """an answer table: rows are lists; a cell given as ('key',) becomes an editable answer cell"""
    def cell(c):
        if isinstance(c, tuple): return '<td class="answer-cell answer-cell-editable" contenteditable="true" data-key="%s" data-placeholder=""></td>' % c[0]
        return '<td>%s</td>' % c
    return '            <table class="data-table answer-table"><tr>%s</tr>%s</table>\n' % (''.join('<th>%s</th>' % h for h in head), ''.join('<tr>%s</tr>' % ''.join(cell(c) for c in r) for r in rows))
def ACELLS(head, rows):
    """model answer for an answer table: same layout, answer cells carry data-key"""
    def cell(c):
        if isinstance(c, tuple): return '<td data-key="%s">%s</td>' % (c[0], c[1])
        return '<td>%s</td>' % c
    return '<table><tr>%s</tr>%s</table>' % (''.join('<th>%s</th>' % h for h in head), ''.join('<tr>%s</tr>' % ''.join(cell(c) for c in r) for r in rows))

def fixunits(s):
    """no space inside compound units: N m -> Nm, kN m -> kNm (also kN m^-1)"""
    s = re.sub(r'(?<=[\d;>)] )(k?N) m(?![a-z])', r'\1m', s)
    return re.sub(r'\b(k?N) m(?=<sup>|&#8722;|\u2212)', r'\1m', s)
