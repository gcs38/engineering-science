# Higher Materials build (11 November 2026; revised 15 November 2026 after colleague review)
Sources: Materials.doc (school notes), Bright Red pp. 84-91 (ideas only, not copied), Higher course spec, 2026 data booklet,
2022-2026 Higher QPs and MIs (question styles only; all questions use original contexts and numbers).
- mlib.py      SVG graph/figure primitives (Graph class, curve(), fig/mini/row/img wrappers)
- diagrams.py  load-extension regions, unloading/permanent set, stress-strain key points, four-material comparison,
               strain energy, gridded task/exam graphs, cross-sections, tube thickness, FoS scale, strain gauge, gauge circuit
- widget.py    tensile test explorer (mild steel, aluminium alloy, cast iron, ABS; zoom on elastic region; remove the load)
- content1.py  intro + sections 1-4 (STEPPER helper, SY symbol sets); content2.py sections 5-8; content3.py exam questions,
               design challenges, TOC_SUB, OUTCOMES
- helpers.py   copied from structures/ (WEL, ASSIGN dict items, C/F/NOTE, sf, tr, fixunits)
- assemble.py  python3 assemble.py "11 November 2026, 13:24" OUTDIR  (template: source-course-notes-2026-11-08.html from structures/)
- answers.py   SITE=/path/to/site python3 answers.py OUTDIR  (password young-modulus; KEY ess-answers-pw-higher-materials)
- No photos: the tensometer and test pieces are original SVG drawings (diagrams.tensometer, diagrams.test_pieces).
Site edits still needed: js/answer-tools.js (ENABLED + OUTCOMES['higher-materials']), js/site.js (status available +
TEACHER_DOCS['higher-materials'] -> answers.html). OUTCOMES text is in content3.OUTCOMES.

## 15 November 2026 revision
- Order: 1 Tensile testing (Task 1 = load-extension graph), 2 Properties (Task 2), 3 Stress and strain, 4 Stress-strain graphs,
  5 Young's modulus, 6 Strain energy, 7 Factor of safety (now includes strength in tension and compression), 8 Strain gauges,
  9 Exam-style questions, 10 Design challenges. Answer keys kept from the first version so pupils' saved answers carry over.
- Worked examples (helpers.WEL) now use the standard grey box and numbered teal steps of the other Higher topics, with larger equation lines.
- Elasticity = area under the elastic part; plasticity = area under the plastic part; ductility = plastic extension before fracture.
- O-A linear (limit of proportionality A, not assessed); O-B elastic; B yield point = end of the elastic region.
- content3.OUTCOMES is now a list of (outcome, section anchor) pairs for js/answer-tools.js.

## 16 November 2026: tensile test simulator demonstrations
- Photos (supplied by GDog) replace the drawn tensometer and test pieces: img/tensometer-labelled.jpg, img/test-pieces-before-after.jpg
  -> higher/mechanisms/materials/images/. (diagrams.tensometer and diagrams.test_pieces are no longer used.)
- Four demonstrations (content1.SIMT): 1 mild steel test with labels (Section 1), 2 comparing materials (Section 2),
  3 stress-strain graphs (Section 4), 4 finding Young's modulus (Section 5). The tensile test explorer (widget.py) is kept for
  removing the load part-way through, which the simulator does not do. The simulator is not credited on the site.
- simulators/mat-tensile-test.html is made by ../tensile-sim/make_sim.py:
    node build_tailwind.mjs source-tensile-sim-v1.html out.css      (compiles the Tailwind classes into a stylesheet)
    python3 make_sim.py source-tensile-sim-v1.html out.css mat-tensile-test.html
  URL options: material=<key>, only=<key,...>, mode=fe, labels=1, gauge=<mm>, area=<mm2>, view=1 (compact embedded layout;
  the set-up panel closes when a test starts). build_tailwind.mjs points at a local tailwindcss v4 package; change the path if needed.

## 16 November 2026 (later): photos for Section 9 and Challenge 3
- Photos replace diagrams: q1-marina-gangway.jpg (Q1), q2-lock-gate-cranes.jpg (Q2), q3-hoppers.jpg + diagrams.leg_section (Q3),
  dc3-jib-crane.jpg (Challenge 3, title strip cropped off the top). diagrams.gangway/hoist/hopper/jib_crane are no longer used.
- Q2 now refers to several lengths of rope on a mobile crane hook (7.5 kN in each length); numbers unchanged.
- Q3 is now a pair of hoppers, each 9600 kg full on its own six legs; new part (a) total force on the base (key hmat-e3f).
- helpers.FB takes an optional class; the factor of safety formula uses 'formula-long' (15px, one line).

## 16 November 2026 (12:26)
- Simulator panels: the sim is laid out at 960 x 540 inside .tsim-wrap and scaled to the column width by TSIM_JS (fit()),
  so the whole sim is always visible and shorter on the page. tensile-sim/make_sim.py also tightens the compact set-up panel.
- diagrams.gauge is now one gauge with tension arrows; bolt bar has a thinner tightening band and a larger safety margin;
  leg_section has no title (the caption gives it) and sits beside the hopper photo in a .pair-row at the same height.
