import { compile } from '/opt/npm-tools/node_modules/tailwindcss/dist/lib.mjs';
import fs from 'fs';
import path from 'path';
const twDir = '/opt/npm-tools/node_modules/tailwindcss';
const html = fs.readFileSync(process.argv[2], 'utf8');
// candidate class names: every token in class="..." attributes and in quoted strings in the script
const cands = new Set();
for (const m of html.matchAll(/class(?:Name)?="([^"]*)"/g)) m[1].split(/\s+/).forEach(c => c && cands.add(c));
for (const m of html.matchAll(/['"`]([^'"`\n]{1,400})['"`]/g)) m[1].split(/\s+/).forEach(c => /^[!a-z0-9:\-\/\[\]\.#%_]+$/i.test(c) && cands.add(c));
const compiler = await compile('@import "tailwindcss";', {
  base: twDir,
  loadStylesheet: async (id, base) => {
    const p = id === 'tailwindcss' ? path.join(twDir, 'index.css') : path.resolve(base, id.replace(/^tailwindcss\//, ''));
    return { content: fs.readFileSync(p, 'utf8'), base: path.dirname(p), path: p };
  },
});
const css = compiler.build([...cands]);
fs.writeFileSync(process.argv[3], css);
console.log('candidates', cands.size, 'css bytes', css.length);
