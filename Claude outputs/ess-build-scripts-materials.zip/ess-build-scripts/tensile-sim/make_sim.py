"""Make simulators/mat-tensile-test.html from the tensile test simulator source.
- Tailwind is compiled into the page (no CDN needed); run build.mjs first to make out.css
- URL options: material=<key>, only=<key,key,...>, mode=fe (force-extension graph), labels=1, gauge=<mm>, area=<mm2>,
  view=1 (compact layout for embedding in the notes: no top toolbar, narrower panels)."""
import sys, re
src, css, out = sys.argv[1], sys.argv[2], sys.argv[3]
h = open(src, encoding='utf-8').read()
tw = open(css, encoding='utf-8').read()
a = '<script src="https://cdn.tailwindcss.com"></script>'
assert h.count(a) == 1
h = h.replace(a, '<style>\n' + tw + '\n</style>')
VIEW_CSS = r'''
        /* ESS: compact layout when embedded in the course notes (?view=1). The set-up panel closes when a test starts. */
        body.ess-view > div:first-child { display:none; }
        body.ess-view #sidebarList { width:14rem; padding:12px; }
        body.ess-view #sidebarList > * + * { margin-top:8px; }
        body.ess-view #sidebarList > div:nth-of-type(1) { display:none; }          /* 'Tensometer lab setup' heading */
        body.ess-view #sidebarList .p-4 { padding:10px; }
        body.ess-view #force-display, body.ess-view #extension-display { font-size:15px; }
        body.ess-view #sidebarList .p-3\.5 { padding:8px 10px; }
        body.ess-view .drawer-open #canvasWrapper { left:14rem; }
        body.ess-view #canvasWrapper { padding:10px; gap:10px; flex-direction:row; }
        body.ess-view #canvasWrapper > div:first-child { width:9.5rem; min-height:0 !important; padding:10px; }
        body.ess-view #canvasWrapper > div:first-child > div:first-child { display:none; }
        body.ess-view #canvasWrapper > div:last-child { padding:10px 10px 10px 26px; }
        body.ess-view #canvasWrapper > div:last-child > div:first-child { flex-wrap:wrap; gap:6px; }
        body.ess-view #canvasWrapper > div:last-child > div:last-child { min-height:0 !important; }
        body.ess-view .machine-track { width:7rem; }
        body.ess-view #legend-container { display:none; }
        body.ess-view .drawer-open #canvasWrapper > div:first-child { display:none; }
        body.ess-view .drawer-closed #btnMenuToggle { right:-3.4rem; width:2.6rem; height:2.6rem; }
        body.ess-view .drawer-closed #iconMenuChevron { transform:rotate(180deg); }
        body.ess-view .drawer-closed #canvasWrapper { padding-left:3.4rem; }
        @media (max-width:560px) { body.ess-view #canvasWrapper > div:first-child { display:none !important; } }
'''
h = h.replace('    </style>\n</head>', VIEW_CSS + '    </style>\n</head>', 1)
URL_JS = r'''
        // ESS: options from the web address, so the course notes can open a demonstration ready to run
        (function () {
            var q = new URLSearchParams(location.search);
            if (q.has('view')) document.body.classList.add('ess-view');
            var sel = document.getElementById('material-select');
            var only = (q.get('only') || '').split(',').filter(function (k) { return materials[k]; });
            if (only.length) Array.prototype.slice.call(sel.options).forEach(function (o) { if (only.indexOf(o.value) < 0) o.remove(); });
            var m = q.get('material'); if (m && (materials[m] || m === 'mystery')) sel.value = m;
            if (q.get('gauge')) document.getElementById('input-gauge').value = q.get('gauge');
            if (q.get('area')) document.getElementById('input-area').value = q.get('area');
            if (q.get('mode') === 'fe') document.getElementById('btnToggleMode').click();
            if (q.get('labels') === '1') document.getElementById('btnToggleLabels').click();
            if (q.has('view')) {
                // close the set-up panel when a test starts, so the machine and graph have the full width
                var start = window.startTest;
                window.startTest = function (isCompare) {
                    start(isCompare);
                    var app = document.getElementById('appContainer');
                    if (app.classList.contains('drawer-open')) document.getElementById('btnMenuToggle').click();
                };
                document.getElementById('start-btn').onclick = function () { window.startTest(false); };
                document.getElementById('compare-btn').onclick = function () { window.startTest(true); };
            }
        })();
'''
a = '        resizeCanvas();\n        resetMachine();\n    </script>'
assert h.count(a) == 1
h = h.replace(a, URL_JS + a)
a = 'const pLeft = 110;'
assert h.count(a) == 2   # graph drawing and mouse hover use the same margin
h = h.replace(a, "const pLeft = document.body.classList.contains('ess-view') ? 92 : 110;")
h = h.replace('<title>NoTensionSim V1</title>', '<title>Tensile test simulator</title>')
open(out, 'w', encoding='utf-8', newline='\n').write(h)
print('ok', len(h))
